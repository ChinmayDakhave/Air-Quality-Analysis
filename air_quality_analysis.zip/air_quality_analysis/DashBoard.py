import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import numpy as np
from utils.data_loader import load_and_preprocess_data, get_data_summary
from utils.visualizations import create_overview_charts
import warnings
warnings.filterwarnings('ignore')

# Page configuration
st.set_page_config(
    page_title="Air Quality Analysis Platform",
    page_icon="🌬️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for professional appearance
st.markdown("""
<style>
    .main-header {
        font-size: 3rem;
        font-weight: bold;
        text-align: center;
        margin-bottom: 2rem;
        background: linear-gradient(90deg, #1f77b4, #17becf);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }
    
    .metric-container {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 1rem;
        border-radius: 10px;
        color: white;
        text-align: center;
        margin: 0.5rem 0;
    }
    
    .info-box {
        background-color: #f0f8ff;
        padding: 1rem;
        border-left: 4px solid #1f77b4;
        border-radius: 5px;
        margin: 1rem 0;
    }
    
    .warning-box {
        background-color: #fff3cd;
        padding: 1rem;
        border-left: 4px solid #ffc107;
        border-radius: 5px;
        margin: 1rem 0;
    }
</style>
""", unsafe_allow_html=True)

@st.cache_data
def load_data():
    """Load and cache the air quality data"""
    return load_and_preprocess_data("attached_assets/city_day_cleaned_1752299155779.csv")

def main():
    # Header
    st.markdown('<h1 class="main-header">🌬️ Air Quality Analysis Platform</h1>', unsafe_allow_html=True)
    
    # Load data
    with st.spinner("Loading air quality data..."):
        data = load_data()
    
    if data is None or data.empty:
        st.error("❌ Failed to load data. Please check the data file.")
        return
    
    # Sidebar
    st.sidebar.title("🎛️ Navigation & Controls")
    st.sidebar.markdown("---")
    
    # Data overview in sidebar
    st.sidebar.subheader("📊 Dataset Overview")
    summary = get_data_summary(data)
    
    st.sidebar.metric("Total Records", f"{summary['total_records']:,}")
    st.sidebar.metric("Cities Covered", summary['cities_count'])
    st.sidebar.metric("Date Range", f"{summary['date_range']['start']} to {summary['date_range']['end']}")
    st.sidebar.metric("Pollutants Tracked", summary['pollutants_count'])
    
    # Quick filters
    st.sidebar.markdown("---")
    st.sidebar.subheader("🔧 Quick Filters")
    
    # City filter
    cities = sorted(data['City'].unique())
    selected_cities = st.sidebar.multiselect(
        "Select Cities",
        cities,
        default=cities[:5] if len(cities) > 5 else cities
    )
    
    # Date range filter
    min_date = data['Date'].min()
    max_date = data['Date'].max()
    
    date_range = st.sidebar.date_input(
        "Select Date Range",
        value=(min_date, max_date),
        min_value=min_date,
        max_value=max_date
    )
    
    # Filter data based on selections
    if selected_cities and len(date_range) == 2:
        filtered_data = data[
            (data['City'].isin(selected_cities)) &
            (data['Date'] >= pd.to_datetime(date_range[0])) &
            (data['Date'] <= pd.to_datetime(date_range[1]))
        ]
    else:
        filtered_data = data
    
    # Main content area
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("📈 Key Metrics Dashboard")
        
        # Key metrics
        metrics_col1, metrics_col2, metrics_col3, metrics_col4 = st.columns(4)
        
        with metrics_col1:
            avg_aqi = filtered_data['AQI'].mean()
            st.metric(
                "Average AQI",
                f"{avg_aqi:.1f}",
                delta=f"{avg_aqi - data['AQI'].mean():.1f}"
            )
        
        with metrics_col2:
            avg_pm25 = filtered_data['PM2.5'].mean()
            st.metric(
                "Average PM2.5",
                f"{avg_pm25:.1f} μg/m³",
                delta=f"{avg_pm25 - data['PM2.5'].mean():.1f}"
            )
        
        with metrics_col3:
            avg_pm10 = filtered_data['PM10'].mean()
            st.metric(
                "Average PM10",
                f"{avg_pm10:.1f} μg/m³",
                delta=f"{avg_pm10 - data['PM10'].mean():.1f}"
            )
        
        with metrics_col4:
            poor_days = len(filtered_data[filtered_data['AQI_Bucket'].isin(['Poor', 'Very Poor', 'Severe'])])
            total_days = len(filtered_data)
            poor_percentage = (poor_days / total_days * 100) if total_days > 0 else 0
            st.metric(
                "Poor Air Quality Days",
                f"{poor_percentage:.1f}%",
                delta=f"{poor_days} days"
            )
    
    with col2:
        st.subheader("🎯 Air Quality Distribution")
        
        # AQI bucket distribution
        aqi_dist = filtered_data['AQI_Bucket'].value_counts()
        
        colors = {
            'Good': '#00e400',
            'Satisfactory': '#ffff00',
            'Moderate': '#ff7e00',
            'Poor': '#ff0000',
            'Very Poor': '#8f3f97',
            'Severe': '#7e0023'
        }
        
        fig_pie = px.pie(
            values=aqi_dist.values,
            names=aqi_dist.index,
            title="AQI Category Distribution",
            color=aqi_dist.index,
            color_discrete_map=colors
        )
        fig_pie.update_layout(height=300)
        st.plotly_chart(fig_pie, use_container_width=True)
    
    # Main visualizations
    st.markdown("---")
    st.subheader("📊 Overview Visualizations")
    
    # Create overview charts
    charts = create_overview_charts(filtered_data)
    
    # AQI trends over time
    st.plotly_chart(charts['aqi_trend'], use_container_width=True)
    
    # Pollutant correlation and city comparison
    col1, col2 = st.columns(2)
    
    with col1:
        st.plotly_chart(charts['pollutant_correlation'], use_container_width=True)
    
    with col2:
        st.plotly_chart(charts['city_comparison'], use_container_width=True)
    
    # Information boxes
    st.markdown("---")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        <div class="info-box">
            <h4>🎓 About This Platform</h4>
            <p>This comprehensive air quality analysis platform provides advanced analytics, 
            machine learning predictions, and professional visualizations for academic research. 
            Navigate through different analysis modules using the sidebar.</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div class="warning-box">
            <h4>⚠️ Data Insights</h4>
            <p>The analysis covers multiple Indian cities with various pollutants including PM2.5, PM10, 
            NO2, O3, and others. Use the filters to focus on specific regions or time periods 
            for detailed analysis.</p>
        </div>
        """, unsafe_allow_html=True)
    
    # Footer
    st.markdown("---")
    st.markdown("""
    <div style="text-align: center; color: #666; margin-top: 2rem;">
        <p>🌍 Air Quality Analysis Platform | Built with Streamlit | Academic Research Project</p>
    </div>
    """, unsafe_allow_html=True)

if __name__ == "__main__":
    main()
