import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np
from utils.data_loader import load_and_preprocess_data, get_data_summary, get_city_statistics
from utils.visualizations import create_distribution_charts
import sys
import os

# Add parent directory to path to import utils
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

st.set_page_config(page_title="Data Overview", page_icon="📊", layout="wide")

st.title("📊 Data Overview & Statistics")
st.markdown("---")

@st.cache_data
def load_data():
    return load_and_preprocess_data("attached_assets/city_day_cleaned_1752299155779.csv")

def main():
    # Load data
    with st.spinner("Loading data..."):
        data = load_data()
    
    if data is None or data.empty:
        st.error("❌ Failed to load data. Please check the data file.")
        return
    
    # Sidebar filters
    st.sidebar.header("🔧 Filters")
    
    # City selection
    cities = sorted(data['City'].unique())
    selected_cities = st.sidebar.multiselect(
        "Select Cities for Analysis",
        cities,
        default=cities[:10] if len(cities) > 10 else cities
    )
    
    # Date range
    min_date = data['Date'].min()
    max_date = data['Date'].max()
    date_range = st.sidebar.date_input(
        "Select Date Range",
        value=(min_date, max_date),
        min_value=min_date,
        max_value=max_date
    )
    
    # Filter data
    if selected_cities and len(date_range) == 2:
        filtered_data = data[
            (data['City'].isin(selected_cities)) &
            (data['Date'] >= pd.to_datetime(date_range[0])) &
            (data['Date'] <= pd.to_datetime(date_range[1]))
        ]
    else:
        filtered_data = data
    
    # Main content
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("📈 Dataset Summary")
        
        # Key statistics
        summary = get_data_summary(filtered_data)
        
        metrics_col1, metrics_col2, metrics_col3, metrics_col4 = st.columns(4)
        
        with metrics_col1:
            st.metric("Total Records", f"{summary['total_records']:,}")
        
        with metrics_col2:
            st.metric("Cities", summary['cities_count'])
        
        with metrics_col3:
            st.metric("Date Span", f"{(pd.to_datetime(summary['date_range']['end']) - pd.to_datetime(summary['date_range']['start'])).days} days")
        
        with metrics_col4:
            st.metric("Pollutants", summary['pollutants_count'])
    
    with col2:
        st.subheader("📊 Quick Stats")
        
        if not filtered_data.empty:
            avg_aqi = filtered_data['AQI'].mean()
            max_aqi = filtered_data['AQI'].max()
            min_aqi = filtered_data['AQI'].min()
            
            st.metric("Average AQI", f"{avg_aqi:.1f}")
            st.metric("Maximum AQI", f"{max_aqi:.1f}")
            st.metric("Minimum AQI", f"{min_aqi:.1f}")
    
    # Data quality assessment
    st.markdown("---")
    st.subheader("🔍 Data Quality Assessment")
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Missing data analysis
        missing_data = filtered_data.isnull().sum()
        missing_percentage = (missing_data / len(filtered_data)) * 100
        
        missing_df = pd.DataFrame({
            'Column': missing_data.index,
            'Missing_Count': missing_data.values,
            'Missing_Percentage': missing_percentage.values
        }).sort_values('Missing_Percentage', ascending=False)
        
        # Only show columns with missing data
        missing_df = missing_df[missing_df['Missing_Count'] > 0]
        
        if not missing_df.empty:
            fig_missing = px.bar(
                missing_df.head(10),
                x='Missing_Percentage',
                y='Column',
                orientation='h',
                title='Missing Data by Column (%)',
                color='Missing_Percentage',
                color_continuous_scale='Reds'
            )
            fig_missing.update_layout(height=400, template='plotly_white')
            st.plotly_chart(fig_missing, use_container_width=True)
        else:
            st.success("✅ No missing data detected in filtered dataset!")
    
    with col2:
        # Data distribution overview
        numeric_columns = ['PM2.5', 'PM10', 'NO2', 'SO2', 'O3', 'CO', 'AQI']
        available_columns = [col for col in numeric_columns if col in filtered_data.columns]
        
        if available_columns:
            # Statistical summary
            stats_df = filtered_data[available_columns].describe().round(2)
            st.write("**Statistical Summary**")
            st.dataframe(stats_df, use_container_width=True)
    
    # Pollutant analysis
    st.markdown("---")
    st.subheader("🌬️ Pollutant Analysis")
    
    # Create distribution charts
    distribution_charts = create_distribution_charts(filtered_data)
    
    # Display AQI distribution
    if 'aqi_distribution' in distribution_charts:
        st.plotly_chart(distribution_charts['aqi_distribution'], use_container_width=True)
    
    # Pollutant correlations
    col1, col2 = st.columns(2)
    
    with col1:
        # Correlation matrix
        pollutant_cols = ['PM2.5', 'PM10', 'NO2', 'SO2', 'O3', 'AQI']
        available_pollutants = [col for col in pollutant_cols if col in filtered_data.columns]
        
        if len(available_pollutants) > 1:
            corr_matrix = filtered_data[available_pollutants].corr()
            
            fig_corr = go.Figure(data=go.Heatmap(
                z=corr_matrix.values,
                x=corr_matrix.columns,
                y=corr_matrix.columns,
                colorscale='RdBu',
                zmid=0,
                text=corr_matrix.round(2).values,
                texttemplate='%{text}',
                textfont={"size": 10}
            ))
            
            fig_corr.update_layout(
                title='Pollutant Correlation Matrix',
                template='plotly_white',
                height=400
            )
            
            st.plotly_chart(fig_corr, use_container_width=True)
    
    with col2:
        # AQI category distribution
        if 'AQI_Bucket' in filtered_data.columns:
            aqi_dist = filtered_data['AQI_Bucket'].value_counts()
            
            colors = {
                'Good': '#00e400',
                'Satisfactory': '#ffff00',
                'Moderate': '#ff7e00',
                'Poor': '#ff0000',
                'Very Poor': '#8f3f97',
                'Severe': '#7e0023'
            }
            
            fig_aqi_pie = px.pie(
                values=aqi_dist.values,
                names=aqi_dist.index,
                title='AQI Category Distribution',
                color=aqi_dist.index,
                color_discrete_map=colors
            )
            fig_aqi_pie.update_layout(height=400)
            st.plotly_chart(fig_aqi_pie, use_container_width=True)
    
    # City-wise analysis
    st.markdown("---")
    st.subheader("🏙️ City-wise Analysis")
    
    # City selection for detailed analysis
    selected_city = st.selectbox(
        "Select a city for detailed statistics:",
        filtered_data['City'].unique()
    )
    
    if selected_city:
        city_stats = get_city_statistics(filtered_data, selected_city)
        
        if city_stats and 'pollutant_stats' in city_stats:
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.write(f"**{selected_city} - Basic Info**")
                st.write(f"Total Records: {city_stats['total_records']}")
                st.write(f"Date Range: {city_stats['date_range']['start']} to {city_stats['date_range']['end']}")
            
            with col2:
                st.write(f"**AQI Distribution**")
                for category, percentage in city_stats['aqi_distribution'].items():
                    st.write(f"{category}: {percentage:.1f}%")
            
            with col3:
                # Key pollutant statistics for the city
                if 'AQI' in city_stats['pollutant_stats']:
                    aqi_stats = city_stats['pollutant_stats']['AQI']
                    st.write(f"**AQI Statistics**")
                    st.write(f"Mean: {aqi_stats['mean']:.1f}")
                    st.write(f"Max: {aqi_stats['max']:.1f}")
                    st.write(f"Min: {aqi_stats['min']:.1f}")
    
    # Temporal patterns
    st.markdown("---")
    st.subheader("📅 Temporal Patterns")
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Monthly patterns
        if 'Month' in filtered_data.columns:
            monthly_aqi = filtered_data.groupby('Month')['AQI'].mean()
            
            fig_monthly = px.line(
                x=monthly_aqi.index,
                y=monthly_aqi.values,
                title='Average AQI by Month',
                labels={'x': 'Month', 'y': 'Average AQI'},
                markers=True
            )
            fig_monthly.update_layout(template='plotly_white', height=400)
            st.plotly_chart(fig_monthly, use_container_width=True)
    
    with col2:
        # Seasonal patterns
        if 'Season' in filtered_data.columns:
            seasonal_aqi = filtered_data.groupby('Season')['AQI'].mean().sort_values(ascending=False)
            
            fig_seasonal = px.bar(
                x=seasonal_aqi.index,
                y=seasonal_aqi.values,
                title='Average AQI by Season',
                labels={'x': 'Season', 'y': 'Average AQI'},
                color=seasonal_aqi.values,
                color_continuous_scale='Reds'
            )
            fig_seasonal.update_layout(template='plotly_white', height=400)
            st.plotly_chart(fig_seasonal, use_container_width=True)
    
    # Data export options
    st.markdown("---")
    st.subheader("💾 Data Export")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("📁 Download Filtered Data (CSV)"):
            csv = filtered_data.to_csv(index=False)
            st.download_button(
                label="Download CSV",
                data=csv,
                file_name=f"air_quality_filtered_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}.csv",
                mime="text/csv"
            )
    
    with col2:
        if st.button("📊 Download Summary Statistics"):
            summary_stats = filtered_data.describe()
            csv = summary_stats.to_csv()
            st.download_button(
                label="Download Statistics",
                data=csv,
                file_name=f"air_quality_stats_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}.csv",
                mime="text/csv"
            )
    
    with col3:
        # Display raw data sample
        if st.checkbox("Show Raw Data Sample"):
            st.dataframe(filtered_data.head(100), use_container_width=True)

if __name__ == "__main__":
    main()
