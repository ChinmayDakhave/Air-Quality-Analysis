import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, ExtraTreesRegressor
from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet
from sklearn.svm import SVR
from sklearn.neural_network import MLPRegressor
from sklearn.tree import DecisionTreeRegressor
from sklearn.neighbors import KNeighborsRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.preprocessing import StandardScaler, RobustScaler, MinMaxScaler
from sklearn.feature_selection import SelectKBest, f_regression, RFE
import warnings
warnings.filterwarnings('ignore')
from utils.data_loader import load_and_preprocess_data
from utils.ml_models import AirQualityPredictor
import sys
import os

# Add parent directory to path to import utils
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

st.set_page_config(page_title="Machine Learning", page_icon="🤖", layout="wide")

st.title("🤖 Machine Learning Analysis")
st.markdown("---")

@st.cache_data
def load_data():
    return load_and_preprocess_data("attached_assets/city_day_cleaned_1752299155779.csv")

class AdvancedMLAnalysis:
    def __init__(self):
        self.models = {
            'Random Forest': RandomForestRegressor(n_estimators=100, random_state=42),
            'Gradient Boosting': GradientBoostingRegressor(n_estimators=100, random_state=42),
            'Extra Trees': ExtraTreesRegressor(n_estimators=100, random_state=42),
            'Linear Regression': LinearRegression(),
            'Ridge Regression': Ridge(alpha=1.0),
            'Lasso Regression': Lasso(alpha=1.0),
            'Elastic Net': ElasticNet(alpha=1.0),
            'Support Vector Regression': SVR(kernel='rbf', C=1.0),
            'Neural Network': MLPRegressor(hidden_layer_sizes=(100, 50), max_iter=500, random_state=42),
            'Decision Tree': DecisionTreeRegressor(random_state=42),
            'K-Nearest Neighbors': KNeighborsRegressor(n_neighbors=5)
        }
        self.scalers = {
            'Standard': StandardScaler(),
            'Robust': RobustScaler(),
            'MinMax': MinMaxScaler(),
            'None': None
        }
        self.trained_models = {}
        self.performance_metrics = {}
        self.feature_importance = {}
        self.best_model = None
        self.best_scaler = None

    def prepare_advanced_features(self, df, target_column='AQI'):
        """Prepare advanced features including engineered features"""
        data = df.copy()
        
        # Remove rows with missing target
        data = data.dropna(subset=[target_column])
        
        feature_columns = []
        
        # Basic pollutant features
        pollutant_features = ['PM2.5', 'PM10', 'NO', 'NO2', 'NOx', 'NH3', 'CO', 'SO2', 'O3', 'Benzene', 'Toluene']
        for col in pollutant_features:
            if col in data.columns and col != target_column:
                feature_columns.append(col)
        
        # Temporal features
        if 'Date' in data.columns:
            data['Year'] = data['Date'].dt.year
            data['Month'] = data['Date'].dt.month
            data['DayOfWeek'] = data['Date'].dt.dayofweek
            data['Quarter'] = data['Date'].dt.quarter
            data['DayOfYear'] = data['Date'].dt.dayofyear
            data['WeekOfYear'] = data['Date'].dt.isocalendar().week
            feature_columns.extend(['Year', 'Month', 'DayOfWeek', 'Quarter', 'DayOfYear', 'WeekOfYear'])
        
        # Seasonal features
        if 'Season' in data.columns:
            season_dummies = pd.get_dummies(data['Season'], prefix='Season')
            data = pd.concat([data, season_dummies], axis=1)
            feature_columns.extend(season_dummies.columns.tolist())
        
        # City encoding
        if 'City' in data.columns:
            city_dummies = pd.get_dummies(data['City'], prefix='City')
            data = pd.concat([data, city_dummies], axis=1)
            feature_columns.extend(city_dummies.columns.tolist())
        
        # Feature engineering
        if 'PM2.5' in data.columns and 'PM10' in data.columns:
            data['PM2.5_to_PM10_ratio'] = data['PM2.5'] / (data['PM10'] + 1e-6)
            feature_columns.append('PM2.5_to_PM10_ratio')
        
        if 'NO' in data.columns and 'NO2' in data.columns:
            data['NO_to_NO2_ratio'] = data['NO'] / (data['NO2'] + 1e-6)
            feature_columns.append('NO_to_NO2_ratio')
        
        # Interaction features (selected pairs)
        interaction_pairs = [('PM2.5', 'PM10'), ('NO2', 'O3'), ('SO2', 'CO')]
        for col1, col2 in interaction_pairs:
            if col1 in data.columns and col2 in data.columns:
                data[f'{col1}_x_{col2}'] = data[col1] * data[col2]
                feature_columns.append(f'{col1}_x_{col2}')
        
        # Lag features (previous day values)
        lag_columns = ['PM2.5', 'PM10', 'NO2', 'AQI']
        data_sorted = data.sort_values(['City', 'Date'])
        for col in lag_columns:
            if col in data_sorted.columns and col != target_column:
                data_sorted[f'{col}_lag1'] = data_sorted.groupby('City')[col].shift(1)
                if f'{col}_lag1' not in feature_columns:
                    feature_columns.append(f'{col}_lag1')
        
        data = data_sorted
        
        # Remove rows with missing features
        data = data.dropna(subset=feature_columns + [target_column])
        
        X = data[feature_columns]
        y = data[target_column]
        
        return X, y, feature_columns, data

    def perform_feature_selection(self, X, y, method='selectk', k=20):
        """Perform feature selection"""
        if method == 'selectk':
            selector = SelectKBest(score_func=f_regression, k=min(k, X.shape[1]))
            X_selected = selector.fit_transform(X, y)
            selected_features = X.columns[selector.get_support()].tolist()
        elif method == 'rfe':
            estimator = RandomForestRegressor(n_estimators=50, random_state=42)
            selector = RFE(estimator=estimator, n_features_to_select=min(k, X.shape[1]))
            X_selected = selector.fit_transform(X, y)
            selected_features = X.columns[selector.get_support()].tolist()
        else:
            X_selected = X
            selected_features = X.columns.tolist()
        
        return X_selected, selected_features, selector if method != 'none' else None

    def hyperparameter_tuning(self, model_name, X, y, cv=3):
        """Perform hyperparameter tuning for selected model"""
        param_grids = {
            'Random Forest': {
                'n_estimators': [50, 100, 200],
                'max_depth': [None, 10, 20],
                'min_samples_split': [2, 5, 10]
            },
            'Gradient Boosting': {
                'n_estimators': [50, 100, 200],
                'learning_rate': [0.01, 0.1, 0.2],
                'max_depth': [3, 5, 7]
            },
            'Ridge Regression': {
                'alpha': [0.1, 1.0, 10.0, 100.0]
            },
            'Support Vector Regression': {
                'C': [0.1, 1.0, 10.0],
                'gamma': ['scale', 'auto'],
                'kernel': ['rbf', 'linear']
            }
        }
        
        if model_name in param_grids:
            model = self.models[model_name]
            param_grid = param_grids[model_name]
            
            grid_search = GridSearchCV(
                model, param_grid, cv=cv, scoring='r2', n_jobs=-1
            )
            grid_search.fit(X, y)
            
            return grid_search.best_estimator_, grid_search.best_params_, grid_search.best_score_
        else:
            return self.models[model_name], {}, None

def create_learning_curves(model, X, y, title):
    """Create learning curves to analyze model performance vs training size"""
    train_sizes = np.linspace(0.1, 1.0, 10)
    train_scores = []
    val_scores = []
    
    for train_size in train_sizes:
        n_samples = int(train_size * len(X))
        if n_samples < 10:
            continue
            
        X_subset = X[:n_samples]
        y_subset = y[:n_samples]
        
        # Cross-validation
        cv_train_scores = []
        cv_val_scores = []
        
        for train_idx, val_idx in KFold(n_splits=3, shuffle=True, random_state=42).split(X_subset):
            X_train_cv, X_val_cv = X_subset.iloc[train_idx], X_subset.iloc[val_idx]
            y_train_cv, y_val_cv = y_subset.iloc[train_idx], y_subset.iloc[val_idx]
            
            model.fit(X_train_cv, y_train_cv)
            
            train_pred = model.predict(X_train_cv)
            val_pred = model.predict(X_val_cv)
            
            cv_train_scores.append(r2_score(y_train_cv, train_pred))
            cv_val_scores.append(r2_score(y_val_cv, val_pred))
        
        train_scores.append(np.mean(cv_train_scores))
        val_scores.append(np.mean(cv_val_scores))
    
    # Plot learning curves
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=train_sizes[:len(train_scores)],
        y=train_scores,
        mode='lines+markers',
        name='Training Score',
        line=dict(color='blue')
    ))
    
    fig.add_trace(go.Scatter(
        x=train_sizes[:len(val_scores)],
        y=val_scores,
        mode='lines+markers',
        name='Validation Score',
        line=dict(color='red')
    ))
    
    fig.update_layout(
        title=f'Learning Curves - {title}',
        xaxis_title='Training Set Size',
        yaxis_title='R² Score',
        template='plotly_white',
        height=400
    )
    
    return fig

def main():
    # Load data
    with st.spinner("Loading data..."):
        data = load_data()
    
    if data is None or data.empty:
        st.error("❌ Failed to load data. Please check the data file.")
        return
    
    # Sidebar controls
    st.sidebar.header("🎛️ ML Configuration")
    
    # Target variable selection
    targets = ['AQI', 'PM2.5', 'PM10', 'NO2', 'SO2', 'O3']
    available_targets = [col for col in targets if col in data.columns]
    target_variable = st.sidebar.selectbox(
        "Select Target Variable",
        available_targets,
        index=0
    )
    
    # Data filtering
    min_date = data['Date'].min()
    max_date = data['Date'].max()
    date_range = st.sidebar.date_input(
        "Training Data Range",
        value=(min_date, max_date),
        min_value=min_date,
        max_value=max_date
    )
    
    # Filter data
    if len(date_range) == 2:
        training_data = data[
            (data['Date'] >= pd.to_datetime(date_range[0])) &
            (data['Date'] <= pd.to_datetime(date_range[1]))
        ].copy()
    else:
        training_data = data.copy()
    
    # Main content
    st.subheader(f"🤖 Machine Learning Analysis for {target_variable}")
    
    # Initialize ML analysis
    ml_analysis = AdvancedMLAnalysis()
    
    # Tabs for different ML tasks
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "Data Preparation", "Model Training", "Model Comparison", "Feature Analysis", "Predictions"
    ])
    
    with tab1:
        st.subheader("📊 Data Preparation & Feature Engineering")
        
        # Prepare features
        with st.spinner("Preparing features..."):
            X, y, feature_names, processed_data = ml_analysis.prepare_advanced_features(training_data, target_variable)
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("**Dataset Information**")
            st.metric("Total Samples", len(X))
            st.metric("Total Features", len(feature_names))
            st.metric("Target Variable", target_variable)
            
            # Data quality metrics
            missing_percentage = (X.isnull().sum() / len(X) * 100).max()
            st.metric("Max Missing %", f"{missing_percentage:.1f}%")
        
        with col2:
            st.write("**Target Variable Distribution**")
            
            fig_target_dist = px.histogram(
                y,
                nbins=50,
                title=f'{target_variable} Distribution',
                labels={'value': target_variable, 'count': 'Frequency'}
            )
            fig_target_dist.update_layout(template='plotly_white', height=300)
            st.plotly_chart(fig_target_dist, use_container_width=True)
        
        # Feature selection
        st.write("**Feature Selection**")
        
        feature_selection_method = st.selectbox(
            "Feature Selection Method",
            ['none', 'selectk', 'rfe'],
            index=1
        )
        
        if feature_selection_method != 'none':
            n_features = st.slider(
                "Number of Features to Select",
                5, min(50, len(feature_names)), 20
            )
            
            X_selected, selected_features, selector = ml_analysis.perform_feature_selection(
                X, y, feature_selection_method, n_features
            )
        else:
            X_selected = X
            selected_features = feature_names
            selector = None
        
        st.write(f"**Selected Features ({len(selected_features)}):**")
        st.write(selected_features)
        
        # Store prepared data in session state
        if 'ml_data' not in st.session_state:
            st.session_state.ml_data = {}
        
        st.session_state.ml_data.update({
            'X': X_selected,
            'y': y,
            'feature_names': selected_features,
            'processed_data': processed_data
        })
    
    with tab2:
        st.subheader("🏋️ Model Training & Evaluation")
        
        if 'ml_data' not in st.session_state:
            st.warning("Please prepare data in the Data Preparation tab first.")
            return
        
        X = st.session_state.ml_data['X']
        y = st.session_state.ml_data['y']
        
        # Training configuration
        col1, col2 = st.columns(2)
        
        with col1:
            # Model selection
            selected_models = st.multiselect(
                "Select Models to Train",
                list(ml_analysis.models.keys()),
                default=['Random Forest', 'Gradient Boosting', 'Linear Regression', 'Ridge Regression']
            )
        
        with col2:
            # Scaling options
            scaler_type = st.selectbox(
                "Data Scaling",
                ['Standard', 'Robust', 'MinMax', 'None'],
                index=0
            )
            
            test_size = st.slider("Test Set Size", 0.1, 0.5, 0.2, 0.05)
        
        # Hyperparameter tuning option
        tune_hyperparameters = st.checkbox("Enable Hyperparameter Tuning (slower)")
        
        if st.button("Train Models"):
            if not selected_models:
                st.error("Please select at least one model.")
                return
            
            with st.spinner("Training models..."):
                # Split data
                X_train, X_test, y_train, y_test = train_test_split(
                    X, y, test_size=test_size, random_state=42
                )
                
                # Apply scaling
                if scaler_type != 'None':
                    scaler = ml_analysis.scalers[scaler_type]
                    X_train_scaled = scaler.fit_transform(X_train)
                    X_test_scaled = scaler.transform(X_test)
                else:
                    X_train_scaled = X_train
                    X_test_scaled = X_test
                    scaler = None
                
                # Train models
                results = {}
                
                for model_name in selected_models:
                    try:
                        # Get model
                        if tune_hyperparameters and model_name in ['Random Forest', 'Gradient Boosting', 'Ridge Regression', 'Support Vector Regression']:
                            model, best_params, best_score = ml_analysis.hyperparameter_tuning(
                                model_name, X_train_scaled, y_train
                            )
                            st.write(f"**{model_name} - Best Parameters:** {best_params}")
                        else:
                            model = ml_analysis.models[model_name]
                        
                        # Train model
                        if scaler_type != 'None' and model_name in ['Support Vector Regression', 'Neural Network', 'Ridge Regression', 'Lasso Regression', 'Elastic Net']:
                            model.fit(X_train_scaled, y_train)
                            y_pred = model.predict(X_test_scaled)
                            cv_scores = cross_val_score(model, X_train_scaled, y_train, cv=5, scoring='r2')
                        else:
                            model.fit(X_train, y_train)
                            y_pred = model.predict(X_test)
                            cv_scores = cross_val_score(model, X_train, y_train, cv=5, scoring='r2')
                        
                        # Calculate metrics
                        mse = mean_squared_error(y_test, y_pred)
                        mae = mean_absolute_error(y_test, y_pred)
                        r2 = r2_score(y_test, y_pred)
                        rmse = np.sqrt(mse)
                        
                        results[model_name] = {
                            'Model': model,
                            'Scaler': scaler,
                            'MSE': mse,
                            'MAE': mae,
                            'RMSE': rmse,
                            'R2': r2,
                            'CV_R2_Mean': cv_scores.mean(),
                            'CV_R2_Std': cv_scores.std(),
                            'Predictions': y_pred,
                            'Actual': y_test.values
                        }
                        
                        # Feature importance for tree-based models
                        if hasattr(model, 'feature_importances_'):
                            feature_names = st.session_state.ml_data['feature_names']
                            ml_analysis.feature_importance[model_name] = dict(
                                zip(feature_names, model.feature_importances_)
                            )
                        
                    except Exception as e:
                        st.error(f"Error training {model_name}: {str(e)}")
                        continue
                
                # Store results
                ml_analysis.performance_metrics = results
                ml_analysis.trained_models = {name: result['Model'] for name, result in results.items()}
                
                # Find best model
                if results:
                    best_model_name = max(results.keys(), key=lambda x: results[x]['R2'])
                    ml_analysis.best_model = results[best_model_name]['Model']
                    ml_analysis.best_scaler = results[best_model_name]['Scaler']
                    
                    st.success(f"✅ Training completed! Best model: {best_model_name} (R² = {results[best_model_name]['R2']:.3f})")
                else:
                    st.error("No models were successfully trained.")
    
    with tab3:
        st.subheader("📊 Model Comparison & Evaluation")
        
        if not ml_analysis.performance_metrics:
            st.warning("Please train models first in the Model Training tab.")
            return
        
        # Performance comparison table
        st.write("**Model Performance Comparison**")
        
        comparison_df = pd.DataFrame({
            model: {
                'R² Score': metrics['R2'],
                'RMSE': metrics['RMSE'],
                'MAE': metrics['MAE'],
                'CV R² Mean': metrics['CV_R2_Mean'],
                'CV R² Std': metrics['CV_R2_Std']
            }
            for model, metrics in ml_analysis.performance_metrics.items()
        }).T.round(4)
        
        st.dataframe(comparison_df, use_container_width=True)
        
        # Performance visualization
        col1, col2 = st.columns(2)
        
        with col1:
            # R² comparison
            r2_scores = [metrics['R2'] for metrics in ml_analysis.performance_metrics.values()]
            model_names = list(ml_analysis.performance_metrics.keys())
            
            fig_r2 = px.bar(
                x=model_names,
                y=r2_scores,
                title='Model Performance (R² Score)',
                color=r2_scores,
                color_continuous_scale='Viridis'
            )
            fig_r2.update_layout(
                template='plotly_white',
                height=400,
                xaxis={'tickangle': 45}
            )
            st.plotly_chart(fig_r2, use_container_width=True)
        
        with col2:
            # RMSE comparison
            rmse_scores = [metrics['RMSE'] for metrics in ml_analysis.performance_metrics.values()]
            
            fig_rmse = px.bar(
                x=model_names,
                y=rmse_scores,
                title='Model Performance (RMSE)',
                color=rmse_scores,
                color_continuous_scale='Reds'
            )
            fig_rmse.update_layout(
                template='plotly_white',
                height=400,
                xaxis={'tickangle': 45}
            )
            st.plotly_chart(fig_rmse, use_container_width=True)
        
        # Actual vs Predicted plots
        st.write("**Actual vs Predicted Analysis**")
        
        selected_model_for_analysis = st.selectbox(
            "Select Model for Detailed Analysis",
            list(ml_analysis.performance_metrics.keys())
        )
        
        if selected_model_for_analysis:
            metrics = ml_analysis.performance_metrics[selected_model_for_analysis]
            actual = metrics['Actual']
            predicted = metrics['Predictions']
            
            col1, col2 = st.columns(2)
            
            with col1:
                # Actual vs Predicted scatter plot
                fig_scatter = go.Figure()
                
                fig_scatter.add_trace(go.Scatter(
                    x=actual,
                    y=predicted,
                    mode='markers',
                    name='Predictions',
                    marker=dict(color='blue', opacity=0.6)
                ))
                
                # Perfect prediction line
                min_val = min(actual.min(), predicted.min())
                max_val = max(actual.max(), predicted.max())
                fig_scatter.add_trace(go.Scatter(
                    x=[min_val, max_val],
                    y=[min_val, max_val],
                    mode='lines',
                    name='Perfect Prediction',
                    line=dict(color='red', dash='dash')
                ))
                
                fig_scatter.update_layout(
                    title=f'Actual vs Predicted - {selected_model_for_analysis}',
                    xaxis_title=f'Actual {target_variable}',
                    yaxis_title=f'Predicted {target_variable}',
                    template='plotly_white',
                    height=400
                )
                
                st.plotly_chart(fig_scatter, use_container_width=True)
            
            with col2:
                # Residual analysis
                residuals = actual - predicted
                
                fig_residual = px.histogram(
                    residuals,
                    nbins=30,
                    title='Residuals Distribution',
                    labels={'value': 'Residuals', 'count': 'Frequency'}
                )
                fig_residual.update_layout(template='plotly_white', height=400)
                st.plotly_chart(fig_residual, use_container_width=True)
            
            # Model-specific metrics
            st.write(f"**{selected_model_for_analysis} - Detailed Metrics**")
            
            metrics_col1, metrics_col2, metrics_col3, metrics_col4 = st.columns(4)
            
            with metrics_col1:
                st.metric("R² Score", f"{metrics['R2']:.4f}")
            with metrics_col2:
                st.metric("RMSE", f"{metrics['RMSE']:.4f}")
            with metrics_col3:
                st.metric("MAE", f"{metrics['MAE']:.4f}")
            with metrics_col4:
                st.metric("CV R² Mean", f"{metrics['CV_R2_Mean']:.4f}")
    
    with tab4:
        st.subheader("🔍 Feature Importance Analysis")
        
        if not ml_analysis.feature_importance:
            st.warning("Feature importance is only available for tree-based models. Please train Random Forest, Gradient Boosting, or Extra Trees models.")
            return
        
        # Feature importance visualization
        selected_model_fi = st.selectbox(
            "Select Model for Feature Importance",
            list(ml_analysis.feature_importance.keys())
        )
        
        if selected_model_fi:
            importance_dict = ml_analysis.feature_importance[selected_model_fi]
            importance_df = pd.DataFrame(
                list(importance_dict.items()),
                columns=['Feature', 'Importance']
            ).sort_values('Importance', ascending=True)
            
            # Top features
            top_n = st.slider("Number of Top Features to Display", 5, 30, 15)
            top_features = importance_df.tail(top_n)
            
            fig_importance = px.bar(
                top_features,
                x='Importance',
                y='Feature',
                orientation='h',
                title=f'Top {top_n} Feature Importance - {selected_model_fi}',
                color='Importance',
                color_continuous_scale='Viridis'
            )
            fig_importance.update_layout(template='plotly_white', height=600)
            st.plotly_chart(fig_importance, use_container_width=True)
            
            # Feature importance statistics
            col1, col2 = st.columns(2)
            
            with col1:
                st.write("**Feature Importance Statistics**")
                st.write(f"Total Features: {len(importance_df)}")
                st.write(f"Top Feature: {importance_df.iloc[-1]['Feature']} ({importance_df.iloc[-1]['Importance']:.4f})")
                st.write(f"Mean Importance: {importance_df['Importance'].mean():.4f}")
                st.write(f"Std Importance: {importance_df['Importance'].std():.4f}")
            
            with col2:
                # Feature categories analysis
                st.write("**Feature Categories**")
                
                feature_categories = {
                    'Pollutants': 0,
                    'Temporal': 0,
                    'Geographical': 0,
                    'Engineered': 0,
                    'Other': 0
                }
                
                for feature in importance_df['Feature']:
                    if any(pollutant in feature for pollutant in ['PM', 'NO', 'SO', 'O3', 'CO', 'NH3', 'Benzene', 'Toluene']):
                        feature_categories['Pollutants'] += 1
                    elif any(temporal in feature for temporal in ['Month', 'Day', 'Year', 'Quarter', 'Week', 'Season']):
                        feature_categories['Temporal'] += 1
                    elif 'City' in feature:
                        feature_categories['Geographical'] += 1
                    elif any(eng in feature for eng in ['ratio', '_x_', 'lag']):
                        feature_categories['Engineered'] += 1
                    else:
                        feature_categories['Other'] += 1
                
                for category, count in feature_categories.items():
                    if count > 0:
                        st.write(f"{category}: {count}")
    
    with tab5:
        st.subheader("🔮 Predictions & Forecasting")
        
        if not ml_analysis.trained_models:
            st.warning("Please train models first in the Model Training tab.")
            return
        
        # Model selection for prediction
        prediction_model = st.selectbox(
            "Select Model for Predictions",
            list(ml_analysis.trained_models.keys())
        )
        
        # Prediction options
        prediction_type = st.radio(
            "Prediction Type",
            ["Single Prediction", "Batch Prediction", "Time Series Forecast"]
        )
        
        if prediction_type == "Single Prediction":
            st.write("**Enter Values for Prediction**")
            
            # Create input fields for features
            feature_names = st.session_state.ml_data['feature_names']
            input_values = {}
            
            # Organize features into categories for better UX
            pollutant_features = [f for f in feature_names if any(p in f for p in ['PM', 'NO', 'SO', 'O3', 'CO', 'NH3', 'Benzene', 'Toluene'])]
            temporal_features = [f for f in feature_names if any(t in f for t in ['Month', 'Day', 'Year', 'Quarter', 'Week'])]
            other_features = [f for f in feature_names if f not in pollutant_features and f not in temporal_features]
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.write("**Pollutant Features**")
                for feature in pollutant_features[:10]:  # Limit to avoid too many inputs
                    if 'lag' not in feature and 'ratio' not in feature and '_x_' not in feature:
                        input_values[feature] = st.number_input(f"{feature}", value=0.0, key=f"input_{feature}")
            
            with col2:
                st.write("**Temporal Features**")
                for feature in temporal_features:
                    if feature == 'Month':
                        input_values[feature] = st.slider("Month", 1, 12, 6, key=f"input_{feature}")
                    elif feature == 'DayOfWeek':
                        input_values[feature] = st.slider("Day of Week", 0, 6, 3, key=f"input_{feature}")
                    elif feature == 'Quarter':
                        input_values[feature] = st.slider("Quarter", 1, 4, 2, key=f"input_{feature}")
                    else:
                        input_values[feature] = st.number_input(f"{feature}", value=0.0, key=f"input_{feature}")
            
            with col3:
                st.write("**Other Features**")
                for feature in other_features[:10]:  # Limit to avoid too many inputs
                    if 'City_' in feature:
                        input_values[feature] = st.checkbox(feature.replace('City_', ''), key=f"input_{feature}")
                    elif 'Season_' in feature:
                        input_values[feature] = st.checkbox(feature.replace('Season_', ''), key=f"input_{feature}")
                    else:
                        input_values[feature] = st.number_input(f"{feature}", value=0.0, key=f"input_{feature}")
            
            # Fill missing features with default values
            for feature in feature_names:
                if feature not in input_values:
                    input_values[feature] = 0.0
            
            if st.button("Make Prediction"):
                try:
                    # Prepare input array
                    input_array = np.array([input_values[f] for f in feature_names]).reshape(1, -1)
                    
                    # Apply scaling if needed
                    model = ml_analysis.trained_models[prediction_model]
                    scaler = ml_analysis.performance_metrics[prediction_model].get('Scaler')
                    
                    if scaler is not None:
                        input_array = scaler.transform(input_array)
                    
                    # Make prediction
                    prediction = model.predict(input_array)[0]
                    
                    st.success(f"**Predicted {target_variable}: {prediction:.2f}**")
                    
                    # Confidence interval (rough estimate based on model performance)
                    model_rmse = ml_analysis.performance_metrics[prediction_model]['RMSE']
                    confidence_lower = prediction - 1.96 * model_rmse
                    confidence_upper = prediction + 1.96 * model_rmse
                    
                    st.info(f"95% Confidence Interval: [{confidence_lower:.2f}, {confidence_upper:.2f}]")
                    
                except Exception as e:
                    st.error(f"Error making prediction: {str(e)}")
        
        elif prediction_type == "Batch Prediction":
            st.write("**Upload CSV file for batch predictions**")
            
            uploaded_file = st.file_uploader("Choose a CSV file", type="csv")
            
            if uploaded_file is not None:
                try:
                    # Read uploaded file
                    batch_data = pd.read_csv(uploaded_file)
                    st.write("**Uploaded Data Preview:**")
                    st.dataframe(batch_data.head(), use_container_width=True)
                    
                    if st.button("Generate Batch Predictions"):
                        # Process data for prediction
                        # This would need the same feature engineering as training data
                        st.info("Batch prediction functionality would require the same feature engineering pipeline as training data.")
                        
                except Exception as e:
                    st.error(f"Error processing uploaded file: {str(e)}")
        
        else:  # Time Series Forecast
            st.write("**Time Series Forecasting**")
            
            forecast_days = st.slider("Number of days to forecast", 1, 30, 7)
            
            # Select city for forecasting
            cities = sorted(training_data['City'].unique())
            forecast_city = st.selectbox("Select City for Forecasting", cities)
            
            if st.button("Generate Forecast"):
                try:
                    # Get recent data for the selected city
                    city_data = training_data[training_data['City'] == forecast_city].sort_values('Date')
                    
                    if len(city_data) < 10:
                        st.error("Insufficient data for forecasting this city.")
                        return
                    
                    # Simple forecasting approach using last known values and trend
                    recent_data = city_data.tail(30)  # Last 30 days
                    
                    # Calculate trend
                    if target_variable in recent_data.columns:
                        y_recent = recent_data[target_variable].dropna()
                        if len(y_recent) > 1:
                            x_recent = np.arange(len(y_recent))
                            trend_slope = np.polyfit(x_recent, y_recent, 1)[0]
                            last_value = y_recent.iloc[-1]
                            
                            # Generate forecast
                            forecast_values = []
                            for i in range(1, forecast_days + 1):
                                forecast_val = last_value + trend_slope * i
                                forecast_values.append(forecast_val)
                            
                            # Create forecast dates
                            last_date = city_data['Date'].max()
                            forecast_dates = pd.date_range(
                                start=last_date + pd.Timedelta(days=1),
                                periods=forecast_days,
                                freq='D'
                            )
                            
                            # Plot forecast
                            fig_forecast = go.Figure()
                            
                            # Historical data
                            fig_forecast.add_trace(go.Scatter(
                                x=recent_data['Date'],
                                y=recent_data[target_variable],
                                mode='lines+markers',
                                name='Historical',
                                line=dict(color='blue')
                            ))
                            
                            # Forecast
                            fig_forecast.add_trace(go.Scatter(
                                x=forecast_dates,
                                y=forecast_values,
                                mode='lines+markers',
                                name='Forecast',
                                line=dict(color='red', dash='dash')
                            ))
                            
                            fig_forecast.update_layout(
                                title=f'{target_variable} Forecast for {forecast_city}',
                                xaxis_title='Date',
                                yaxis_title=target_variable,
                                template='plotly_white',
                                height=500
                            )
                            
                            st.plotly_chart(fig_forecast, use_container_width=True)
                            
                            # Forecast summary
                            st.write("**Forecast Summary:**")
                            forecast_df = pd.DataFrame({
                                'Date': forecast_dates,
                                'Predicted_Value': forecast_values
                            })
                            st.dataframe(forecast_df, use_container_width=True)
                        else:
                            st.error("Insufficient data points for trend calculation.")
                    else:
                        st.error(f"Target variable {target_variable} not found in city data.")
                        
                except Exception as e:
                    st.error(f"Error generating forecast: {str(e)}")

if __name__ == "__main__":
    main()
