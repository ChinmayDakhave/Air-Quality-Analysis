import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np
from utils.data_loader import load_and_preprocess_data
from utils.health_metrics import HealthImpactCalculator, create_health_summary_metrics
import sys
import os

# Add parent directory to path to import utils
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

st.set_page_config(page_title="Health Impact Assessment", page_icon="🏥", layout="wide")

st.title("🏥 Health Impact Assessment")
st.markdown("---")

@st.cache_data
def load_data():
    return load_and_preprocess_data("attached_assets/city_day_cleaned_1752299155779.csv")

def create_health_risk_calculator():
    """Create an interactive health risk calculator"""
    st.subheader("🧮 Personal Health Risk Calculator")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("**Personal Information**")
        age = st.slider("Age", 0, 100, 30)
        
        vulnerable_group = st.selectbox(
            "Vulnerable Group Status",
            ["None", "Child (<12 years)", "Elderly (>65 years)", "Pregnant", "Respiratory Disease", "Cardiovascular Disease"]
        )
        
        activity_level = st.selectbox(
            "Daily Activity Level",
            ["Low (Mostly Indoor)", "Moderate (Some Outdoor)", "High (Frequent Outdoor)", "Very High (Heavy Outdoor Work)"]
        )
    
    with col2:
        st.write("**Current Air Quality Exposure**")
        current_pm25 = st.number_input("Current PM2.5 (μg/m³)", 0.0, 500.0, 35.0)
        current_pm10 = st.number_input("Current PM10 (μg/m³)", 0.0, 500.0, 50.0)
        current_no2 = st.number_input("Current NO2 (μg/m³)", 0.0, 200.0, 40.0)
        current_o3 = st.number_input("Current O3 (μg/m³)", 0.0, 300.0, 100.0)
    
    if st.button("Calculate Health Risk"):
        # Base risk calculation
        base_risk = 0
        
        # PM2.5 risk
        if current_pm25 > 15:  # WHO guideline
            base_risk += (current_pm25 - 15) * 0.1
        
        # PM10 risk
        if current_pm10 > 45:  # WHO guideline
            base_risk += (current_pm10 - 45) * 0.05
        
        # NO2 risk
        if current_no2 > 25:  # WHO guideline
            base_risk += (current_no2 - 25) * 0.08
        
        # O3 risk
        if current_o3 > 60:  # WHO guideline
            base_risk += (current_o3 - 60) * 0.03
        
        # Adjust for personal factors
        vulnerability_multiplier = {
            "None": 1.0,
            "Child (<12 years)": 1.5,
            "Elderly (>65 years)": 1.4,
            "Pregnant": 1.3,
            "Respiratory Disease": 2.0,
            "Cardiovascular Disease": 1.8
        }
        
        activity_multiplier = {
            "Low (Mostly Indoor)": 0.7,
            "Moderate (Some Outdoor)": 1.0,
            "High (Frequent Outdoor)": 1.3,
            "Very High (Heavy Outdoor Work)": 1.6
        }
        
        adjusted_risk = base_risk * vulnerability_multiplier[vulnerable_group] * activity_multiplier[activity_level]
        
        # Risk categorization
        if adjusted_risk <= 5:
            risk_category = "Low"
            risk_color = "green"
        elif adjusted_risk <= 15:
            risk_category = "Moderate"
            risk_color = "yellow"
        elif adjusted_risk <= 30:
            risk_category = "High"
            risk_color = "orange"
        else:
            risk_category = "Very High"
            risk_color = "red"
        
        # Display results
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Personal Health Risk Score", f"{adjusted_risk:.1f}")
        
        with col2:
            st.markdown(f"**Risk Category:** <span style='color: {risk_color}'>{risk_category}</span>", unsafe_allow_html=True)
        
        with col3:
            risk_percentile = min(100, (adjusted_risk / 50) * 100)
            st.metric("Risk Percentile", f"{risk_percentile:.0f}%")
        
        # Recommendations
        st.write("**Personalized Recommendations:**")
        
        if risk_category == "Low":
            st.success("✅ Your current risk is low. Continue monitoring air quality and maintain healthy habits.")
        elif risk_category == "Moderate":
            st.warning("⚠️ Moderate risk detected. Consider limiting outdoor activities during high pollution days.")
        elif risk_category == "High":
            st.error("🚨 High risk! Use air purifiers indoors, wear N95 masks outdoors, and avoid outdoor exercise during peak pollution.")
        else:
            st.error("🆘 Very high risk! Consult healthcare provider, use HEPA air purifiers, minimize outdoor exposure.")
        
        # Specific recommendations based on vulnerable group
        if vulnerable_group != "None":
            st.write(f"**Additional recommendations for {vulnerable_group}:**")
            
            if "Child" in vulnerable_group:
                st.write("- Ensure schools have good air filtration systems")
                st.write("- Schedule outdoor play during early morning hours")
                st.write("- Monitor for respiratory symptoms")
            elif "Elderly" in vulnerable_group:
                st.write("- Have rescue medications readily available")
                st.write("- Consider air purifiers in living areas")
                st.write("- Regular health check-ups")
            elif "Pregnant" in vulnerable_group:
                st.write("- Use air purifiers in home, especially bedroom")
                st.write("- Avoid busy roads and traffic areas")
                st.write("- Discuss with healthcare provider about air quality concerns")

def create_health_economics_analysis(df):
    """Create health economics analysis"""
    st.subheader("💰 Health Economics Analysis")
    
    # Estimated health costs per case (in USD)
    health_costs = {
        'Respiratory_Disease': 2500,
        'Cardiovascular_Disease': 5000,
        'Asthma_Attack': 1200,
        'Premature_Death': 150000,  # Value of Statistical Life (simplified)
        'Hospital_Visit': 800,
        'Emergency_Visit': 1500
    }
    
    # Calculate health impacts for different cities
    calculator = HealthImpactCalculator()
    df_health = calculator.calculate_health_risk_scores(df)
    
    # Estimate health costs by city
    city_health_costs = []
    
    for city in df_health['City'].unique():
        city_data = df_health[df_health['City'] == city]
        
        if len(city_data) == 0:
            continue
        
        avg_risk = city_data['Overall_Health_Risk'].mean()
        population = 1000000  # Assumed city population for calculation
        
        # Estimate health impacts (simplified model)
        respiratory_cases = (avg_risk / 100) * population * 0.05
        cardiovascular_cases = (avg_risk / 100) * population * 0.03
        asthma_attacks = (avg_risk / 100) * population * 0.08
        premature_deaths = (avg_risk / 100) * population * 0.001
        hospital_visits = (avg_risk / 100) * population * 0.1
        emergency_visits = (avg_risk / 100) * population * 0.02
        
        # Calculate total costs
        total_cost = (
            respiratory_cases * health_costs['Respiratory_Disease'] +
            cardiovascular_cases * health_costs['Cardiovascular_Disease'] +
            asthma_attacks * health_costs['Asthma_Attack'] +
            premature_deaths * health_costs['Premature_Death'] +
            hospital_visits * health_costs['Hospital_Visit'] +
            emergency_visits * health_costs['Emergency_Visit']
        )
        
        city_health_costs.append({
            'City': city,
            'Health_Risk_Score': avg_risk,
            'Estimated_Annual_Cost_USD': total_cost,
            'Cost_Per_Capita_USD': total_cost / population,
            'Respiratory_Cases': respiratory_cases,
            'Cardiovascular_Cases': cardiovascular_cases,
            'Premature_Deaths': premature_deaths
        })
    
    costs_df = pd.DataFrame(city_health_costs).sort_values('Estimated_Annual_Cost_USD', ascending=False)
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Top 10 cities by health costs
        top_cost_cities = costs_df.head(10)
        
        fig_costs = px.bar(
            top_cost_cities,
            x='City',
            y='Estimated_Annual_Cost_USD',
            title='Top 10 Cities by Estimated Annual Health Costs',
            color='Health_Risk_Score',
            color_continuous_scale='Reds'
        )
        fig_costs.update_layout(
            template='plotly_white',
            height=400,
            xaxis={'tickangle': 45},
            yaxis_title='Annual Health Cost (USD)'
        )
        st.plotly_chart(fig_costs, use_container_width=True)
    
    with col2:
        # Cost per capita
        fig_per_capita = px.bar(
            top_cost_cities,
            x='City',
            y='Cost_Per_Capita_USD',
            title='Health Cost Per Capita',
            color='Cost_Per_Capita_USD',
            color_continuous_scale='Oranges'
        )
        fig_per_capita.update_layout(
            template='plotly_white',
            height=400,
            xaxis={'tickangle': 45}
        )
        st.plotly_chart(fig_per_capita, use_container_width=True)
    
    # Summary statistics
    st.write("**Health Economics Summary:**")
    
    total_estimated_cost = costs_df['Estimated_Annual_Cost_USD'].sum()
    total_estimated_deaths = costs_df['Premature_Deaths'].sum()
    total_respiratory = costs_df['Respiratory_Cases'].sum()
    
    metrics_col1, metrics_col2, metrics_col3, metrics_col4 = st.columns(4)
    
    with metrics_col1:
        st.metric("Total Estimated Annual Cost", f"${total_estimated_cost/1e9:.1f}B")
    
    with metrics_col2:
        st.metric("Estimated Annual Deaths", f"{total_estimated_deaths:,.0f}")
    
    with metrics_col3:
        st.metric("Respiratory Cases", f"{total_respiratory:,.0f}")
    
    with metrics_col4:
        avg_cost_per_capita = costs_df['Cost_Per_Capita_USD'].mean()
        st.metric("Avg Cost Per Capita", f"${avg_cost_per_capita:.0f}")
    
    # Cost-benefit analysis of pollution reduction
    st.write("**Cost-Benefit Analysis of Pollution Reduction:**")
    
    reduction_scenarios = [10, 20, 30, 40, 50]
    cost_savings = []
    
    for reduction in reduction_scenarios:
        # Assume cost savings proportional to risk reduction
        savings = total_estimated_cost * (reduction / 100) * 0.8  # 80% efficiency factor
        cost_savings.append({
            'Pollution_Reduction_%': reduction,
            'Estimated_Savings_USD': savings,
            'Lives_Saved': total_estimated_deaths * (reduction / 100) * 0.8
        })
    
    savings_df = pd.DataFrame(cost_savings)
    
    fig_savings = go.Figure()
    
    fig_savings.add_trace(go.Scatter(
        x=savings_df['Pollution_Reduction_%'],
        y=savings_df['Estimated_Savings_USD'] / 1e9,
        mode='lines+markers',
        name='Cost Savings (Billions USD)',
        line=dict(color='green'),
        yaxis='y'
    ))
    
    fig_savings.add_trace(go.Scatter(
        x=savings_df['Pollution_Reduction_%'],
        y=savings_df['Lives_Saved'],
        mode='lines+markers',
        name='Lives Saved',
        line=dict(color='blue'),
        yaxis='y2'
    ))
    
    fig_savings.update_layout(
        title='Cost-Benefit Analysis of Pollution Reduction',
        xaxis_title='Pollution Reduction (%)',
        yaxis=dict(title='Cost Savings (Billions USD)', side='left'),
        yaxis2=dict(title='Lives Saved', side='right', overlaying='y'),
        template='plotly_white',
        height=400
    )
    
    st.plotly_chart(fig_savings, use_container_width=True)

def main():
    # Load data
    with st.spinner("Loading data..."):
        data = load_data()
    
    if data is None or data.empty:
        st.error("❌ Failed to load data. Please check the data file.")
        return
    
    # Sidebar controls
    st.sidebar.header("🎛️ Health Analysis Controls")
    
    # Date range filter
    min_date = data['Date'].min()
    max_date = data['Date'].max()
    date_range = st.sidebar.date_input(
        "Select Date Range",
        value=(min_date, max_date),
        min_value=min_date,
        max_value=max_date
    )
    
    # City filter
    cities = sorted(data['City'].unique())
    selected_cities = st.sidebar.multiselect(
        "Select Cities for Analysis",
        cities,
        default=cities[:10] if len(cities) > 10 else cities
    )
    
    # Filter data
    if len(date_range) == 2 and selected_cities:
        filtered_data = data[
            (data['Date'] >= pd.to_datetime(date_range[0])) &
            (data['Date'] <= pd.to_datetime(date_range[1])) &
            (data['City'].isin(selected_cities))
        ].copy()
    else:
        filtered_data = data.copy()
    
    # Main content
    # Health summary metrics
    summary_metrics = create_health_summary_metrics(filtered_data)
    
    st.subheader("📊 Health Impact Overview")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            "Average Health Risk",
            f"{summary_metrics['average_health_risk']:.1f}",
            help="Overall health risk score based on pollutant levels"
        )
    
    with col2:
        st.metric(
            "High Risk Days",
            f"{summary_metrics['high_risk_percentage']:.1f}%",
            help="Percentage of days with high health risk"
        )
    
    with col3:
        st.metric(
            "Vulnerable Population Risk",
            f"{summary_metrics['vulnerable_population_risk']:.1f}",
            help="Enhanced risk score for vulnerable populations"
        )
    
    with col4:
        st.metric(
            "WHO Compliance",
            f"{summary_metrics['who_compliance_rate']:.1f}%",
            help="Compliance rate with WHO air quality guidelines"
        )
    
    # Tabs for different analyses
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "Health Risk Assessment", "WHO Guidelines", "Health Economics", "Personal Risk Calculator", "Recommendations"
    ])
    
    with tab1:
        st.subheader("🏥 Comprehensive Health Risk Assessment")
        
        # Initialize health calculator
        calculator = HealthImpactCalculator()
        
        # Create health impact visualizations
        health_charts = calculator.create_health_impact_visualizations(filtered_data)
        
        # Display health risk distribution
        if 'health_risk_distribution' in health_charts:
            col1, col2 = st.columns(2)
            
            with col1:
                st.plotly_chart(health_charts['health_risk_distribution'], use_container_width=True)
            
            with col2:
                # Health risk by city
                if 'city_health_risk' in health_charts:
                    st.plotly_chart(health_charts['city_health_risk'], use_container_width=True)
        
        # Health trends over time
        if 'health_trends' in health_charts:
            st.plotly_chart(health_charts['health_trends'], use_container_width=True)
        
        # Detailed health impact analysis
        st.write("**Health Impact Categories Analysis**")
        
        df_health = calculator.calculate_health_risk_scores(filtered_data)
        
        # Create health impact summary by city
        city_health_summary = df_health.groupby('City').agg({
            'Respiratory_Risk_Score': 'mean',
            'Cardiovascular_Risk_Score': 'mean',
            'Overall_Health_Risk': 'mean',
            'Vulnerable_Population_Risk': 'mean'
        }).round(2).sort_values('Overall_Health_Risk', ascending=False)
        
        st.dataframe(city_health_summary, use_container_width=True)
        
        # Health risk correlations with pollutants
        st.write("**Health Risk vs Pollutant Correlations**")
        
        pollutants = ['PM2.5', 'PM10', 'NO2', 'SO2', 'O3']
        available_pollutants = [col for col in pollutants if col in df_health.columns]
        
        if available_pollutants:
            correlations = []
            for pollutant in available_pollutants:
                corr_resp = df_health[pollutant].corr(df_health['Respiratory_Risk_Score'])
                corr_cardio = df_health[pollutant].corr(df_health['Cardiovascular_Risk_Score'])
                corr_overall = df_health[pollutant].corr(df_health['Overall_Health_Risk'])
                
                correlations.append({
                    'Pollutant': pollutant,
                    'Respiratory_Risk_Corr': corr_resp,
                    'Cardiovascular_Risk_Corr': corr_cardio,
                    'Overall_Risk_Corr': corr_overall
                })
            
            corr_df = pd.DataFrame(correlations)
            st.dataframe(corr_df.round(3), use_container_width=True)
    
    with tab2:
        st.subheader("🌍 WHO Guidelines Compliance Analysis")
        
        # WHO compliance analysis
        calculator = HealthImpactCalculator()
        compliance = calculator.calculate_who_guideline_compliance(filtered_data)
        
        if compliance:
            # Display WHO compliance chart
            health_charts = calculator.create_health_impact_visualizations(filtered_data)
            if 'who_compliance' in health_charts:
                st.plotly_chart(health_charts['who_compliance'], use_container_width=True)
            
            # Detailed compliance table
            st.write("**WHO Guidelines Compliance Details**")
            
            compliance_details = []
            for pollutant, data in compliance.items():
                compliance_details.append({
                    'Pollutant': pollutant,
                    'WHO_Threshold': data['threshold'],
                    'Days_Exceeding': data['exceeding_days'],
                    'Total_Days': data['total_days'],
                    'Compliance_Rate_%': data['compliance_rate'],
                    'Mean_Concentration': data['mean_concentration'],
                    'Max_Concentration': data['max_concentration']
                })
            
            compliance_df = pd.DataFrame(compliance_details)
            st.dataframe(compliance_df.round(2), use_container_width=True)
            
            # Worst performing cities for each pollutant
            st.write("**Cities with Worst WHO Compliance**")
            
            for pollutant in compliance.keys():
                if pollutant in filtered_data.columns:
                    city_exceedances = filtered_data[filtered_data[pollutant] > compliance[pollutant]['threshold']].groupby('City').size().sort_values(ascending=False)
                    
                    if not city_exceedances.empty:
                        st.write(f"**{pollutant} - Top 5 Cities with Most Exceedances:**")
                        top_5 = city_exceedances.head(5)
                        for i, (city, count) in enumerate(top_5.items(), 1):
                            st.write(f"{i}. {city}: {count} days")
        else:
            st.info("No WHO guideline data available for the selected pollutants.")
    
    with tab3:
        # Health economics analysis
        create_health_economics_analysis(filtered_data)
    
    with tab4:
        # Personal health risk calculator
        create_health_risk_calculator()
    
    with tab5:
        st.subheader("💡 Health Recommendations & Action Plans")
        
        # Generate recommendations
        calculator = HealthImpactCalculator()
        recommendations = calculator.generate_health_recommendations(filtered_data)
        
        # Display recommendations in organized sections
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("**🏥 General Health Recommendations**")
            for rec in recommendations['general']:
                st.write(f"- {rec}")
            
            st.write("**👥 Vulnerable Population Recommendations**")
            for rec in recommendations['vulnerable_populations']:
                st.write(f"- {rec}")
        
        with col2:
            st.write("**🏛️ Policy Recommendations**")
            for rec in recommendations['policy']:
                st.write(f"- {rec}")
            
            st.write("**🛡️ Individual Protection Measures**")
            for rec in recommendations['individual']:
                st.write(f"- {rec}")
        
        # Action priority matrix
        st.write("**🎯 Action Priority Matrix**")
        
        df_health = calculator.calculate_health_risk_scores(filtered_data)
        avg_risk = df_health['Overall_Health_Risk'].mean()
        compliance = calculator.calculate_who_guideline_compliance(filtered_data)
        avg_compliance = np.mean([data['compliance_rate'] for data in compliance.values()]) if compliance else 100
        
        # Create priority matrix
        priority_actions = []
        
        if avg_risk > 20:
            priority_actions.append({
                'Action': 'Immediate Health Emergency Response',
                'Priority': 'Critical',
                'Timeline': 'Immediate (0-30 days)',
                'Impact': 'High'
            })
        
        if avg_compliance < 70:
            priority_actions.append({
                'Action': 'Policy Intervention for WHO Compliance',
                'Priority': 'High',
                'Timeline': 'Short-term (1-6 months)',
                'Impact': 'High'
            })
        
        priority_actions.extend([
            {
                'Action': 'Public Awareness Campaigns',
                'Priority': 'Medium',
                'Timeline': 'Medium-term (6-12 months)',
                'Impact': 'Medium'
            },
            {
                'Action': 'Air Quality Monitoring Enhancement',
                'Priority': 'Medium',
                'Timeline': 'Medium-term (6-12 months)',
                'Impact': 'Medium'
            },
            {
                'Action': 'Healthcare System Strengthening',
                'Priority': 'High',
                'Timeline': 'Long-term (1-2 years)',
                'Impact': 'High'
            }
        ])
        
        priority_df = pd.DataFrame(priority_actions)
        st.dataframe(priority_df, use_container_width=True)
        
        # Health benefits from pollution reduction
        st.write("**💚 Potential Health Benefits from Pollution Reduction**")
        
        health_charts = calculator.create_health_impact_visualizations(filtered_data)
        if 'health_benefits' in health_charts:
            st.plotly_chart(health_charts['health_benefits'], use_container_width=True)
        
        # Specific health targets
        st.write("**🎯 Recommended Health Targets**")
        
        current_avg_aqi = filtered_data['AQI'].mean()
        target_aqi = 50  # Good air quality threshold
        
        if current_avg_aqi > target_aqi:
            reduction_needed = ((current_avg_aqi - target_aqi) / current_avg_aqi) * 100
            st.info(f"**Target:** Reduce average AQI from {current_avg_aqi:.1f} to {target_aqi} (≈{reduction_needed:.1f}% reduction needed)")
        else:
            st.success(f"**Achievement:** Current average AQI ({current_avg_aqi:.1f}) meets good air quality standards!")
        
        # WHO compliance targets
        if compliance:
            for pollutant, data in compliance.items():
                if data['compliance_rate'] < 90:
                    improvement_needed = 90 - data['compliance_rate']
                    st.info(f"**{pollutant} Target:** Improve compliance from {data['compliance_rate']:.1f}% to 90% (+{improvement_needed:.1f}% improvement needed)")

if __name__ == "__main__":
    main()
