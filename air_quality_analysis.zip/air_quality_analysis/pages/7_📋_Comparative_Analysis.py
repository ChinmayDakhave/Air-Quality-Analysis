import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np
from scipy import stats
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from utils.data_loader import load_and_preprocess_data, get_city_statistics
from utils.visualizations import create_custom_chart
import sys
import os

# Add parent directory to path to import utils
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

st.set_page_config(page_title="Comparative Analysis", page_icon="📋", layout="wide")

st.title("📋 Comprehensive Comparative Analysis")
st.markdown("---")

@st.cache_data
def load_data():
    return load_and_preprocess_data("attached_assets/city_day_cleaned_1752299155779.csv")

def perform_statistical_tests(group1, group2, test_type='ttest'):
    """Perform statistical tests between two groups"""
    try:
        if test_type == 'ttest':
            statistic, p_value = stats.ttest_ind(group1.dropna(), group2.dropna())
            test_name = "Independent T-Test"
        elif test_type == 'mannwhitney':
            statistic, p_value = stats.mannwhitneyu(group1.dropna(), group2.dropna(), alternative='two-sided')
            test_name = "Mann-Whitney U Test"
        elif test_type == 'kstest':
            statistic, p_value = stats.ks_2samp(group1.dropna(), group2.dropna())
            test_name = "Kolmogorov-Smirnov Test"
        else:
            return None
        
        return {
            'test_name': test_name,
            'statistic': statistic,
            'p_value': p_value,
            'significant': p_value < 0.05
        }
    except Exception as e:
        return {'error': str(e)}

def create_comparison_radar_chart(data, entities, pollutants, title):
    """Create radar chart for multi-entity comparison"""
    fig = go.Figure()
    
    # Normalize data for radar chart
    normalized_data = data[pollutants].copy()
    for col in pollutants:
        max_val = normalized_data[col].max()
        if max_val > 0:
            normalized_data[col] = normalized_data[col] / max_val
    
    colors = px.colors.qualitative.Set1
    
    for i, entity in enumerate(entities):
        entity_data = normalized_data[data.index.isin([entity]) if hasattr(data.index, 'isin') else 
                                     data['Entity'].isin([entity]) if 'Entity' in data.columns else 
                                     data.iloc[i:i+1]]
        
        if len(entity_data) > 0:
            values = entity_data.iloc[0].values.tolist()
            values += [values[0]]  # Close the radar chart
            
            fig.add_trace(go.Scatterpolar(
                r=values,
                theta=pollutants + [pollutants[0]],
                fill='toself',
                name=str(entity),
                line_color=colors[i % len(colors)]
            ))
    
    fig.update_layout(
        polar=dict(
            radialaxis=dict(visible=True, range=[0, 1])
        ),
        title=title,
        template='plotly_white',
        height=500
    )
    
    return fig

def create_ranking_analysis(data, entities, metric_columns):
    """Create comprehensive ranking analysis"""
    rankings = {}
    
    for metric in metric_columns:
        if metric in data.columns:
            entity_values = []
            for entity in entities:
                if isinstance(data.index, pd.Index) and entity in data.index:
                    value = data.loc[entity, metric]
                elif 'Entity' in data.columns:
                    entity_data = data[data['Entity'] == entity]
                    value = entity_data[metric].mean() if len(entity_data) > 0 else np.nan
                else:
                    value = np.nan
                
                entity_values.append({'Entity': entity, 'Value': value})
            
            entity_df = pd.DataFrame(entity_values).dropna()
            entity_df['Rank'] = entity_df['Value'].rank(ascending=False, method='dense')
            rankings[metric] = entity_df.set_index('Entity')['Rank'].to_dict()
    
    return rankings

def perform_cluster_analysis(data, features, n_clusters=3):
    """Perform cluster analysis on entities"""
    # Prepare data for clustering
    cluster_data = data[features].dropna()
    
    if len(cluster_data) < 2:
        return None, None, None
    
    # Standardize features
    scaler = StandardScaler()
    scaled_data = scaler.fit_transform(cluster_data)
    
    # Perform K-means clustering
    kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    clusters = kmeans.fit_predict(scaled_data)
    
    # Add cluster labels to data
    cluster_data['Cluster'] = clusters
    
    # Calculate cluster centroids in original scale
    centroids = pd.DataFrame(
        scaler.inverse_transform(kmeans.cluster_centers_),
        columns=features
    )
    centroids['Cluster'] = range(n_clusters)
    
    return cluster_data, centroids, kmeans

def create_trend_comparison(data, entities, time_col, value_col, title):
    """Create trend comparison chart"""
    fig = go.Figure()
    
    colors = px.colors.qualitative.Set1
    
    for i, entity in enumerate(entities):
        entity_data = data[data['Entity'] == entity] if 'Entity' in data.columns else data[data.index == entity]
        
        if len(entity_data) > 0:
            fig.add_trace(go.Scatter(
                x=entity_data[time_col],
                y=entity_data[value_col],
                mode='lines+markers',
                name=str(entity),
                line=dict(color=colors[i % len(colors)])
            ))
    
    fig.update_layout(
        title=title,
        xaxis_title=time_col,
        yaxis_title=value_col,
        template='plotly_white',
        height=500
    )
    
    return fig

def main():
    # Load data
    with st.spinner("Loading data..."):
        data = load_data()
    
    if data is None or data.empty:
        st.error("❌ Failed to load data. Please check the data file.")
        return
    
    # Sidebar controls
    st.sidebar.header("🎛️ Comparison Controls")
    
    # Comparison type selection
    comparison_type = st.sidebar.selectbox(
        "Select Comparison Type",
        ["City Comparison", "Time Period Comparison", "Pollutant Comparison", "Regional Comparison", "Seasonal Comparison"]
    )
    
    # Date range filter
    min_date = data['Date'].min()
    max_date = data['Date'].max()
    date_range = st.sidebar.date_input(
        "Select Date Range",
        value=(min_date, max_date),
        min_value=min_date,
        max_value=max_date
    )
    
    # Filter data by date
    if len(date_range) == 2:
        filtered_data = data[
            (data['Date'] >= pd.to_datetime(date_range[0])) &
            (data['Date'] <= pd.to_datetime(date_range[1]))
        ].copy()
    else:
        filtered_data = data.copy()
    
    # Main content based on comparison type
    if comparison_type == "City Comparison":
        st.subheader("🏙️ City-to-City Comparative Analysis")
        
        # City selection
        cities = sorted(filtered_data['City'].unique())
        selected_cities = st.multiselect(
            "Select Cities for Comparison (2-10 cities recommended)",
            cities,
            default=cities[:5] if len(cities) >= 5 else cities
        )
        
        if len(selected_cities) < 2:
            st.warning("Please select at least 2 cities for comparison.")
            return
        
        # Filter data for selected cities
        city_data = filtered_data[filtered_data['City'].isin(selected_cities)].copy()
        
        # Tabs for different city comparison analyses
        tab1, tab2, tab3, tab4, tab5 = st.tabs([
            "Overview Comparison", "Statistical Tests", "Ranking Analysis", "Cluster Analysis", "Trend Comparison"
        ])
        
        with tab1:
            st.write("**City Overview Comparison**")
            
            # Calculate city statistics
            pollutants = ['PM2.5', 'PM10', 'NO2', 'SO2', 'O3', 'AQI']
            available_pollutants = [col for col in pollutants if col in city_data.columns]
            
            city_stats = city_data.groupby('City')[available_pollutants].agg([
                'mean', 'std', 'min', 'max', 'count'
            ]).round(2)
            
            # Flatten column names
            city_stats.columns = [f'{col}_{stat}' for col, stat in city_stats.columns]
            
            col1, col2 = st.columns(2)
            
            with col1:
                # Radar chart comparison
                mean_cols = [col for col in city_stats.columns if col.endswith('_mean')]
                base_pollutants = [col.replace('_mean', '') for col in mean_cols]
                
                if len(base_pollutants) > 2:
                    radar_data = city_stats[mean_cols]
                    radar_data.columns = base_pollutants
                    
                    fig_radar = create_comparison_radar_chart(
                        radar_data, selected_cities, base_pollutants,
                        "City Comparison - Average Pollutant Levels (Normalized)"
                    )
                    st.plotly_chart(fig_radar, use_container_width=True)
            
            with col2:
                # City ranking bar chart
                selected_pollutant = st.selectbox(
                    "Select pollutant for ranking",
                    available_pollutants,
                    key="city_ranking_pollutant"
                )
                
                city_means = city_data.groupby('City')[selected_pollutant].mean().sort_values(ascending=False)
                
                fig_ranking = px.bar(
                    x=city_means.index,
                    y=city_means.values,
                    title=f'City Ranking by Average {selected_pollutant}',
                    color=city_means.values,
                    color_continuous_scale='Reds'
                )
                fig_ranking.update_layout(
                    template='plotly_white',
                    height=400,
                    xaxis={'tickangle': 45}
                )
                st.plotly_chart(fig_ranking, use_container_width=True)
            
            # Detailed statistics table
            st.write("**Detailed City Statistics**")
            st.dataframe(city_stats, use_container_width=True)
        
        with tab2:
            st.write("**Statistical Significance Tests**")
            
            # Select cities for pairwise comparison
            col1, col2 = st.columns(2)
            
            with col1:
                city1 = st.selectbox("Select First City", selected_cities, key="stat_city1")
            
            with col2:
                city2 = st.selectbox("Select Second City", 
                                   [c for c in selected_cities if c != city1], 
                                   key="stat_city2")
            
            # Select pollutant and test type
            col1, col2 = st.columns(2)
            
            with col1:
                test_pollutant = st.selectbox(
                    "Select Pollutant for Testing",
                    available_pollutants,
                    key="test_pollutant"
                )
            
            with col2:
                test_type = st.selectbox(
                    "Select Statistical Test",
                    ['ttest', 'mannwhitney', 'kstest'],
                    format_func=lambda x: {
                        'ttest': 'Independent T-Test',
                        'mannwhitney': 'Mann-Whitney U Test',
                        'kstest': 'Kolmogorov-Smirnov Test'
                    }[x]
                )
            
            if st.button("Perform Statistical Test"):
                city1_data = city_data[city_data['City'] == city1][test_pollutant]
                city2_data = city_data[city_data['City'] == city2][test_pollutant]
                
                test_result = perform_statistical_tests(city1_data, city2_data, test_type)
                
                if test_result and 'error' not in test_result:
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        st.metric("Test Statistic", f"{test_result['statistic']:.4f}")
                    
                    with col2:
                        st.metric("P-value", f"{test_result['p_value']:.4e}")
                    
                    with col3:
                        significance = "Significant" if test_result['significant'] else "Not Significant"
                        st.metric("Result (α=0.05)", significance)
                    
                    # Interpretation
                    if test_result['significant']:
                        st.success(f"✅ **Significant difference detected** between {city1} and {city2} for {test_pollutant}")
                    else:
                        st.info(f"ℹ️ **No significant difference** between {city1} and {city2} for {test_pollutant}")
                    
                    # Box plot comparison
                    comparison_data = pd.DataFrame({
                        'City': [city1] * len(city1_data) + [city2] * len(city2_data),
                        'Value': list(city1_data) + list(city2_data)
                    })
                    
                    fig_box = px.box(
                        comparison_data,
                        x='City',
                        y='Value',
                        title=f'{test_pollutant} Distribution Comparison: {city1} vs {city2}'
                    )
                    fig_box.update_layout(template='plotly_white', height=400)
                    st.plotly_chart(fig_box, use_container_width=True)
                
                else:
                    st.error(f"Error performing statistical test: {test_result.get('error', 'Unknown error')}")
        
        with tab3:
            st.write("**City Ranking Analysis**")
            
            # Multi-criteria ranking
            ranking_pollutants = st.multiselect(
                "Select pollutants for ranking analysis",
                available_pollutants,
                default=available_pollutants[:4]
            )
            
            if ranking_pollutants:
                city_means = city_data.groupby('City')[ranking_pollutants].mean()
                rankings = create_ranking_analysis(city_means, selected_cities, ranking_pollutants)
                
                # Create ranking table
                ranking_df = pd.DataFrame(rankings).fillna(0)
                ranking_df['Average_Rank'] = ranking_df.mean(axis=1)
                ranking_df = ranking_df.sort_values('Average_Rank')
                
                col1, col2 = st.columns(2)
                
                with col1:
                    st.write("**Multi-Criteria Ranking Table**")
                    st.dataframe(ranking_df.round(1), use_container_width=True)
                
                with col2:
                    # Ranking visualization
                    fig_rank_visual = px.bar(
                        x=ranking_df.index,
                        y=ranking_df['Average_Rank'],
                        title='Overall City Ranking (Lower is Better)',
                        color=ranking_df['Average_Rank'],
                        color_continuous_scale='RdYlGn_r'
                    )
                    fig_rank_visual.update_layout(
                        template='plotly_white',
                        height=400,
                        xaxis={'tickangle': 45}
                    )
                    st.plotly_chart(fig_rank_visual, use_container_width=True)
                
                # Best and worst performers
                st.write("**Performance Summary**")
                col1, col2 = st.columns(2)
                
                with col1:
                    best_city = ranking_df.index[0]
                    st.success(f"🏆 **Best Overall Performance:** {best_city}")
                    st.write(f"Average Rank: {ranking_df.loc[best_city, 'Average_Rank']:.1f}")
                
                with col2:
                    worst_city = ranking_df.index[-1]
                    st.error(f"⚠️ **Needs Most Improvement:** {worst_city}")
                    st.write(f"Average Rank: {ranking_df.loc[worst_city, 'Average_Rank']:.1f}")
        
        with tab4:
            st.write("**Cluster Analysis**")
            
            # Select features for clustering
            cluster_features = st.multiselect(
                "Select features for clustering",
                available_pollutants,
                default=available_pollutants[:4]
            )
            
            n_clusters = st.slider("Number of clusters", 2, 6, 3)
            
            if len(cluster_features) >= 2 and st.button("Perform Cluster Analysis"):
                city_means = city_data.groupby('City')[cluster_features].mean()
                city_means['Entity'] = city_means.index
                
                cluster_result, centroids, kmeans_model = perform_cluster_analysis(
                    city_means, cluster_features, n_clusters
                )
                
                if cluster_result is not None:
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        # Cluster visualization (2D PCA)
                        if len(cluster_features) > 2:
                            scaler = StandardScaler()
                            scaled_data = scaler.fit_transform(city_means[cluster_features])
                            pca = PCA(n_components=2)
                            pca_data = pca.fit_transform(scaled_data)
                            
                            fig_cluster = px.scatter(
                                x=pca_data[:, 0],
                                y=pca_data[:, 1],
                                color=cluster_result['Cluster'].astype(str),
                                text=city_means.index,
                                title='City Clusters (PCA Visualization)',
                                labels={'x': f'PC1 ({pca.explained_variance_ratio_[0]:.1%} variance)',
                                       'y': f'PC2 ({pca.explained_variance_ratio_[1]:.1%} variance)'}
                            )
                            fig_cluster.update_traces(textposition="top center")
                            fig_cluster.update_layout(template='plotly_white', height=500)
                            st.plotly_chart(fig_cluster, use_container_width=True)
                        else:
                            # Simple 2D scatter for 2 features
                            fig_cluster = px.scatter(
                                city_means,
                                x=cluster_features[0],
                                y=cluster_features[1],
                                color=cluster_result['Cluster'].astype(str),
                                text=city_means.index,
                                title='City Clusters'
                            )
                            fig_cluster.update_traces(textposition="top center")
                            fig_cluster.update_layout(template='plotly_white', height=500)
                            st.plotly_chart(fig_cluster, use_container_width=True)
                    
                    with col2:
                        # Cluster characteristics
                        st.write("**Cluster Characteristics**")
                        
                        for cluster_id in range(n_clusters):
                            cluster_cities = cluster_result[cluster_result['Cluster'] == cluster_id].index.tolist()
                            st.write(f"**Cluster {cluster_id + 1}:**")
                            st.write(f"Cities: {', '.join(cluster_cities)}")
                            
                            # Cluster centroid values
                            centroid_values = centroids[centroids['Cluster'] == cluster_id][cluster_features].iloc[0]
                            for feature, value in centroid_values.items():
                                st.write(f"- {feature}: {value:.2f}")
                            st.write("---")
        
        with tab5:
            st.write("**Temporal Trend Comparison**")
            
            # Select pollutant for trend analysis
            trend_pollutant = st.selectbox(
                "Select pollutant for trend analysis",
                available_pollutants,
                key="trend_pollutant"
            )
            
            # Time aggregation level
            time_agg = st.selectbox(
                "Time aggregation",
                ["Daily", "Weekly", "Monthly", "Quarterly"],
                index=2
            )
            
            # Prepare data for trend analysis
            trend_data = city_data.copy()
            trend_data['Entity'] = trend_data['City']
            
            if time_agg == "Weekly":
                trend_data['Time_Period'] = trend_data['Date'].dt.to_period('W').astype(str)
            elif time_agg == "Monthly":
                trend_data['Time_Period'] = trend_data['Date'].dt.to_period('M').astype(str)
            elif time_agg == "Quarterly":
                trend_data['Time_Period'] = trend_data['Date'].dt.to_period('Q').astype(str)
            else:
                trend_data['Time_Period'] = trend_data['Date']
            
            # Aggregate data
            if time_agg != "Daily":
                trend_agg = trend_data.groupby(['Entity', 'Time_Period'])[trend_pollutant].mean().reset_index()
            else:
                trend_agg = trend_data[['Entity', 'Time_Period', trend_pollutant]].copy()
            
            # Create trend comparison chart
            fig_trends = create_trend_comparison(
                trend_agg, selected_cities, 'Time_Period', trend_pollutant,
                f'{time_agg} {trend_pollutant} Trends Comparison'
            )
            st.plotly_chart(fig_trends, use_container_width=True)
            
            # Trend statistics
            st.write("**Trend Statistics**")
            
            trend_stats = []
            for city in selected_cities:
                city_trend_data = trend_agg[trend_agg['Entity'] == city].copy()
                if len(city_trend_data) > 1:
                    # Calculate trend slope
                    x_vals = np.arange(len(city_trend_data))
                    y_vals = city_trend_data[trend_pollutant].values
                    slope, intercept, r_value, p_value, std_err = stats.linregress(x_vals, y_vals)
                    
                    trend_stats.append({
                        'City': city,
                        'Trend_Slope': slope,
                        'R_Squared': r_value**2,
                        'P_Value': p_value,
                        'Trend_Direction': 'Increasing' if slope > 0 else 'Decreasing',
                        'Significant': 'Yes' if p_value < 0.05 else 'No'
                    })
            
            if trend_stats:
                trend_stats_df = pd.DataFrame(trend_stats)
                st.dataframe(trend_stats_df.round(4), use_container_width=True)
    
    elif comparison_type == "Time Period Comparison":
        st.subheader("📅 Time Period Comparative Analysis")
        
        # Time period selection
        period_type = st.selectbox(
            "Select comparison type",
            ["Year-over-Year", "Month-over-Month", "Season-over-Season", "Custom Periods"]
        )
        
        if period_type == "Year-over-Year":
            available_years = sorted(filtered_data['Date'].dt.year.unique())
            selected_years = st.multiselect(
                "Select years for comparison",
                available_years,
                default=available_years[-2:] if len(available_years) >= 2 else available_years
            )
            
            if len(selected_years) >= 2:
                # Analyze year-over-year changes
                year_data = filtered_data[filtered_data['Date'].dt.year.isin(selected_years)].copy()
                year_data['Year'] = year_data['Date'].dt.year
                
                pollutants = ['PM2.5', 'PM10', 'NO2', 'SO2', 'O3', 'AQI']
                available_pollutants = [col for col in pollutants if col in year_data.columns]
                
                # Calculate yearly averages
                yearly_stats = year_data.groupby('Year')[available_pollutants].mean()
                
                col1, col2 = st.columns(2)
                
                with col1:
                    # Year-over-year comparison chart
                    selected_pollutant = st.selectbox(
                        "Select pollutant for comparison",
                        available_pollutants
                    )
                    
                    fig_yoy = px.bar(
                        x=yearly_stats.index.astype(str),
                        y=yearly_stats[selected_pollutant],
                        title=f'Year-over-Year {selected_pollutant} Comparison',
                        color=yearly_stats[selected_pollutant],
                        color_continuous_scale='RdYlBu_r'
                    )
                    fig_yoy.update_layout(template='plotly_white', height=400)
                    st.plotly_chart(fig_yoy, use_container_width=True)
                
                with col2:
                    # Calculate percentage changes
                    pct_changes = yearly_stats.pct_change() * 100
                    
                    st.write("**Year-over-Year Percentage Changes**")
                    for year in pct_changes.index[1:]:
                        st.write(f"**{year-1} to {year}:**")
                        for pollutant in available_pollutants:
                            change = pct_changes.loc[year, pollutant]
                            if not pd.isna(change):
                                direction = "↑" if change > 0 else "↓"
                                color = "red" if change > 0 else "green"
                                st.markdown(f"- {pollutant}: <span style='color: {color}'>{direction} {abs(change):.1f}%</span>", 
                                          unsafe_allow_html=True)
                
                # Statistical significance of year-over-year changes
                st.write("**Statistical Significance of Changes**")
                
                for i in range(len(selected_years) - 1):
                    year1, year2 = selected_years[i], selected_years[i + 1]
                    year1_data = year_data[year_data['Year'] == year1]
                    year2_data = year_data[year_data['Year'] == year2]
                    
                    st.write(f"**{year1} vs {year2}:**")
                    
                    for pollutant in available_pollutants:
                        test_result = perform_statistical_tests(
                            year1_data[pollutant], 
                            year2_data[pollutant], 
                            'ttest'
                        )
                        
                        if test_result and 'error' not in test_result:
                            significance = "Significant" if test_result['significant'] else "Not Significant"
                            st.write(f"- {pollutant}: {significance} (p={test_result['p_value']:.4f})")
        
        elif period_type == "Season-over-Season":
            if 'Season' in filtered_data.columns:
                seasons = filtered_data['Season'].unique()
                selected_seasons = st.multiselect(
                    "Select seasons for comparison",
                    seasons,
                    default=list(seasons)
                )
                
                if len(selected_seasons) >= 2:
                    season_data = filtered_data[filtered_data['Season'].isin(selected_seasons)].copy()
                    
                    pollutants = ['PM2.5', 'PM10', 'NO2', 'SO2', 'O3', 'AQI']
                    available_pollutants = [col for col in pollutants if col in season_data.columns]
                    
                    # Seasonal comparison
                    seasonal_stats = season_data.groupby('Season')[available_pollutants].agg(['mean', 'std'])
                    
                    # Multi-pollutant seasonal comparison
                    fig_seasonal = make_subplots(
                        rows=2, cols=2,
                        subplot_titles=available_pollutants[:4],
                        specs=[[{"secondary_y": False}, {"secondary_y": False}],
                               [{"secondary_y": False}, {"secondary_y": False}]]
                    )
                    
                    for i, pollutant in enumerate(available_pollutants[:4]):
                        row = (i // 2) + 1
                        col = (i % 2) + 1
                        
                        seasonal_means = seasonal_stats[pollutant]['mean']
                        
                        fig_seasonal.add_trace(
                            go.Bar(x=seasonal_means.index, y=seasonal_means.values, 
                                  name=pollutant, showlegend=False),
                            row=row, col=col
                        )
                    
                    fig_seasonal.update_layout(
                        title='Seasonal Pollutant Comparison',
                        template='plotly_white',
                        height=600
                    )
                    
                    st.plotly_chart(fig_seasonal, use_container_width=True)
                    
                    # Seasonal ranking
                    st.write("**Seasonal Pollution Ranking**")
                    
                    for pollutant in available_pollutants:
                        seasonal_ranking = seasonal_stats[pollutant]['mean'].sort_values(ascending=False)
                        st.write(f"**{pollutant} (Highest to Lowest):**")
                        for rank, (season, value) in enumerate(seasonal_ranking.items(), 1):
                            st.write(f"{rank}. {season}: {value:.2f}")
            else:
                st.warning("Season information not available in the dataset.")
    
    elif comparison_type == "Pollutant Comparison":
        st.subheader("🧪 Pollutant Comparative Analysis")
        
        # Pollutant selection
        pollutants = ['PM2.5', 'PM10', 'NO', 'NO2', 'NOx', 'NH3', 'CO', 'SO2', 'O3', 'Benzene', 'Toluene']
        available_pollutants = [col for col in pollutants if col in filtered_data.columns]
        
        selected_pollutants = st.multiselect(
            "Select pollutants for comparison",
            available_pollutants,
            default=available_pollutants[:5] if len(available_pollutants) >= 5 else available_pollutants
        )
        
        if len(selected_pollutants) >= 2:
            # Pollutant correlation analysis
            st.write("**Pollutant Correlation Analysis**")
            
            corr_matrix = filtered_data[selected_pollutants].corr()
            
            fig_corr = go.Figure(data=go.Heatmap(
                z=corr_matrix.values,
                x=corr_matrix.columns,
                y=corr_matrix.columns,
                colorscale='RdBu',
                zmid=0,
                text=corr_matrix.round(2).values,
                texttemplate='%{text}',
                textfont={"size": 10},
                showscale=True
            ))
            
            fig_corr.update_layout(
                title='Pollutant Correlation Matrix',
                template='plotly_white',
                height=500
            )
            
            st.plotly_chart(fig_corr, use_container_width=True)
            
            # Strongest correlations
            st.write("**Strongest Pollutant Correlations**")
            
            correlations = []
            for i in range(len(corr_matrix.columns)):
                for j in range(i+1, len(corr_matrix.columns)):
                    correlations.append({
                        'Pollutant_1': corr_matrix.columns[i],
                        'Pollutant_2': corr_matrix.columns[j],
                        'Correlation': corr_matrix.iloc[i, j]
                    })
            
            corr_df = pd.DataFrame(correlations).sort_values('Correlation', key=abs, ascending=False)
            st.dataframe(corr_df.head(10).round(3), use_container_width=True)
            
            # Pollutant distribution comparison
            st.write("**Pollutant Distribution Comparison**")
            
            fig_dist = go.Figure()
            
            for pollutant in selected_pollutants:
                fig_dist.add_trace(go.Box(
                    y=filtered_data[pollutant],
                    name=pollutant,
                    boxpoints='outliers'
                ))
            
            fig_dist.update_layout(
                title='Pollutant Distribution Comparison',
                yaxis_title='Concentration',
                template='plotly_white',
                height=500
            )
            
            st.plotly_chart(fig_dist, use_container_width=True)
            
            # Pollutant variability analysis
            st.write("**Pollutant Variability Analysis**")
            
            variability_stats = filtered_data[selected_pollutants].agg([
                'mean', 'std', 'min', 'max', 'skew', 'kurt'
            ]).round(3)
            
            # Calculate coefficient of variation
            variability_stats.loc['cv'] = variability_stats.loc['std'] / variability_stats.loc['mean']
            
            st.dataframe(variability_stats, use_container_width=True)
    
    else:  # Regional or Seasonal Comparison
        st.subheader("🌍 Regional/Seasonal Comparative Analysis")
        
        # This would include more advanced regional analysis
        # Similar structure to other comparison types
        st.info("Advanced regional and seasonal comparison features coming soon!")
    
    # Export functionality
    st.markdown("---")
    st.subheader("💾 Export Comparison Results")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("📊 Export Analysis Summary"):
            # Create summary report
            summary_data = {
                'Comparison_Type': comparison_type,
                'Date_Range': f"{date_range[0]} to {date_range[1]}" if len(date_range) == 2 else "Full range",
                'Analysis_Timestamp': pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            
            summary_df = pd.DataFrame([summary_data])
            csv = summary_df.to_csv(index=False)
            
            st.download_button(
                label="Download Summary",
                data=csv,
                file_name=f"comparison_analysis_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}.csv",
                mime="text/csv"
            )
    
    with col2:
        if st.button("📈 Export Charts Data"):
            st.info("Chart data export functionality would be implemented here.")
    
    with col3:
        if st.button("📋 Generate Report"):
            st.info("Automated report generation functionality would be implemented here.")

if __name__ == "__main__":
    main()
