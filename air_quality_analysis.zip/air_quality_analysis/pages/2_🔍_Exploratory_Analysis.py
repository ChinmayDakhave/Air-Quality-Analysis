import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np
from utils.data_loader import load_and_preprocess_data, filter_data_by_conditions
from utils.visualizations import create_custom_chart, create_advanced_analytics_charts
import sys
import os

# Add parent directory to path to import utils
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

st.set_page_config(page_title="Exploratory Analysis", page_icon="🔍", layout="wide")

st.title("🔍 Exploratory Data Analysis")
st.markdown("---")

@st.cache_data
def load_data():
    return load_and_preprocess_data("attached_assets/city_day_cleaned_1752299155779.csv")

def create_interactive_scatter_matrix(df, selected_pollutants):
    """Create an interactive scatter matrix for selected pollutants"""
    if len(selected_pollutants) < 2:
        return None
    
    # Create scatter matrix
    fig = go.Figure()
    
    # For simplicity, create scatter plots for first few combinations
    combinations = [(selected_pollutants[i], selected_pollutants[j]) 
                   for i in range(len(selected_pollutants)) 
                   for j in range(i+1, len(selected_pollutants))]
    
    if combinations:
        x_var, y_var = combinations[0]  # Take first combination
        
        fig = px.scatter(
            df,
            x=x_var,
            y=y_var,
            color='AQI',
            title=f'{x_var} vs {y_var}',
            color_continuous_scale='Viridis',
            hover_data=['City', 'Date']
        )
        
        fig.update_layout(template='plotly_white', height=500)
    
    return fig

def create_outlier_analysis(df):
    """Identify and visualize outliers in the data"""
    pollutants = ['PM2.5', 'PM10', 'NO2', 'SO2', 'O3', 'AQI']
    available_pollutants = [col for col in pollutants if col in df.columns]
    
    outlier_data = []
    
    for pollutant in available_pollutants:
        Q1 = df[pollutant].quantile(0.25)
        Q3 = df[pollutant].quantile(0.75)
        IQR = Q3 - Q1
        
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        
        outliers = df[(df[pollutant] < lower_bound) | (df[pollutant] > upper_bound)]
        outlier_count = len(outliers)
        outlier_percentage = (outlier_count / len(df)) * 100
        
        outlier_data.append({
            'Pollutant': pollutant,
            'Outlier_Count': outlier_count,
            'Outlier_Percentage': outlier_percentage,
            'Lower_Bound': lower_bound,
            'Upper_Bound': upper_bound
        })
    
    return pd.DataFrame(outlier_data)

def main():
    # Load data
    with st.spinner("Loading data..."):
        data = load_data()
    
    if data is None or data.empty:
        st.error("❌ Failed to load data. Please check the data file.")
        return
    
    # Sidebar for advanced filters
    st.sidebar.header("🎛️ Advanced Filters")
    
    # City selection
    cities = sorted(data['City'].unique())
    selected_cities = st.sidebar.multiselect(
        "Select Cities",
        cities,
        default=cities[:5] if len(cities) > 5 else cities
    )
    
    # Date range
    min_date = data['Date'].min()
    max_date = data['Date'].max()
    date_range = st.sidebar.date_input(
        "Date Range",
        value=(min_date, max_date),
        min_value=min_date,
        max_value=max_date
    )
    
    # AQI range filter
    aqi_range = st.sidebar.slider(
        "AQI Range",
        min_value=int(data['AQI'].min()),
        max_value=int(data['AQI'].max()),
        value=(int(data['AQI'].min()), int(data['AQI'].max()))
    )
    
    # Season filter
    if 'Season' in data.columns:
        seasons = data['Season'].unique()
        selected_seasons = st.sidebar.multiselect(
            "Select Seasons",
            seasons,
            default=seasons
        )
    else:
        selected_seasons = []
    
    # Apply filters
    filter_conditions = {
        'cities': selected_cities if selected_cities else None,
        'date_range': date_range if len(date_range) == 2 else None,
        'aqi_range': aqi_range,
        'seasons': selected_seasons if selected_seasons else None
    }
    
    filtered_data = filter_data_by_conditions(data, filter_conditions)
    
    # Main analysis sections
    st.subheader("📊 Filtered Data Summary")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Records", f"{len(filtered_data):,}")
    
    with col2:
        st.metric("Cities", filtered_data['City'].nunique())
    
    with col3:
        st.metric("Avg AQI", f"{filtered_data['AQI'].mean():.1f}")
    
    with col4:
        poor_air_days = len(filtered_data[filtered_data['AQI'] > 100])
        st.metric("Poor Air Days", poor_air_days)
    
    # Advanced analytics charts
    st.markdown("---")
    st.subheader("📈 Advanced Analytics")
    
    advanced_charts = create_advanced_analytics_charts(filtered_data)
    
    # Display advanced charts
    if 'pm_ratio' in advanced_charts:
        st.plotly_chart(advanced_charts['pm_ratio'], use_container_width=True)
    
    if 'monthly_trends' in advanced_charts:
        st.plotly_chart(advanced_charts['monthly_trends'], use_container_width=True)
    
    # Interactive analysis section
    st.markdown("---")
    st.subheader("🎯 Interactive Analysis")
    
    tab1, tab2, tab3, tab4 = st.tabs(["Scatter Analysis", "Outlier Detection", "Distribution Analysis", "Custom Charts"])
    
    with tab1:
        st.write("**Pollutant Relationship Analysis**")
        
        col1, col2 = st.columns(2)
        
        with col1:
            pollutants = ['PM2.5', 'PM10', 'NO2', 'SO2', 'O3', 'CO', 'AQI']
            available_pollutants = [col for col in pollutants if col in filtered_data.columns]
            
            x_pollutant = st.selectbox("Select X-axis pollutant:", available_pollutants, key="x_scatter")
            y_pollutant = st.selectbox("Select Y-axis pollutant:", available_pollutants, index=1, key="y_scatter")
            color_by = st.selectbox("Color by:", ['AQI', 'City', 'Season', 'Month'], key="color_scatter")
        
        with col2:
            if x_pollutant and y_pollutant and x_pollutant != y_pollutant:
                fig_scatter = px.scatter(
                    filtered_data,
                    x=x_pollutant,
                    y=y_pollutant,
                    color=color_by,
                    title=f'{x_pollutant} vs {y_pollutant}',
                    hover_data=['City', 'Date', 'AQI'],
                    opacity=0.7
                )
                fig_scatter.update_layout(template='plotly_white', height=500)
                st.plotly_chart(fig_scatter, use_container_width=True)
    
    with tab2:
        st.write("**Outlier Detection Analysis**")
        
        outlier_analysis = create_outlier_analysis(filtered_data)
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.dataframe(outlier_analysis, use_container_width=True)
        
        with col2:
            if not outlier_analysis.empty:
                fig_outliers = px.bar(
                    outlier_analysis,
                    x='Pollutant',
                    y='Outlier_Percentage',
                    title='Outlier Percentage by Pollutant',
                    color='Outlier_Percentage',
                    color_continuous_scale='Reds'
                )
                fig_outliers.update_layout(template='plotly_white', height=400)
                st.plotly_chart(fig_outliers, use_container_width=True)
        
        # Detailed outlier analysis for selected pollutant
        selected_pollutant = st.selectbox(
            "Select pollutant for detailed outlier analysis:",
            outlier_analysis['Pollutant'].tolist()
        )
        
        if selected_pollutant:
            pollutant_data = filtered_data[selected_pollutant]
            Q1 = pollutant_data.quantile(0.25)
            Q3 = pollutant_data.quantile(0.75)
            IQR = Q3 - Q1
            
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            
            fig_box = px.box(
                filtered_data,
                y=selected_pollutant,
                title=f'{selected_pollutant} Distribution with Outliers',
                points="outliers"
            )
            fig_box.update_layout(template='plotly_white', height=400)
            st.plotly_chart(fig_box, use_container_width=True)
    
    with tab3:
        st.write("**Distribution Analysis**")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Histogram analysis
            hist_pollutant = st.selectbox(
                "Select pollutant for histogram:",
                [col for col in ['PM2.5', 'PM10', 'NO2', 'SO2', 'O3', 'AQI'] if col in filtered_data.columns],
                key="hist_pollutant"
            )
            
            bins = st.slider("Number of bins:", 10, 100, 30)
            
            if hist_pollutant:
                fig_hist = px.histogram(
                    filtered_data,
                    x=hist_pollutant,
                    nbins=bins,
                    title=f'{hist_pollutant} Distribution',
                    marginal="box"
                )
                fig_hist.update_layout(template='plotly_white', height=500)
                st.plotly_chart(fig_hist, use_container_width=True)
        
        with col2:
            # Density plots by category
            density_pollutant = st.selectbox(
                "Select pollutant for density analysis:",
                [col for col in ['PM2.5', 'PM10', 'NO2', 'SO2', 'O3', 'AQI'] if col in filtered_data.columns],
                key="density_pollutant"
            )
            
            group_by = st.selectbox("Group by:", ['AQI_Bucket', 'Season', 'City'], key="group_density")
            
            if density_pollutant and group_by in filtered_data.columns:
                # Create violin plot
                fig_violin = px.violin(
                    filtered_data,
                    y=density_pollutant,
                    x=group_by,
                    title=f'{density_pollutant} Distribution by {group_by}',
                    box=True
                )
                fig_violin.update_layout(template='plotly_white', height=500)
                st.plotly_chart(fig_violin, use_container_width=True)
    
    with tab4:
        st.write("**Custom Chart Builder**")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            chart_type = st.selectbox(
                "Chart Type:",
                ['scatter', 'line', 'bar', 'box'],
                key="custom_chart_type"
            )
        
        with col2:
            x_column = st.selectbox(
                "X-axis:",
                filtered_data.columns.tolist(),
                key="custom_x"
            )
        
        with col3:
            y_column = st.selectbox(
                "Y-axis:",
                [col for col in filtered_data.columns if filtered_data[col].dtype in ['int64', 'float64']],
                key="custom_y"
            )
        
        color_column = st.selectbox(
            "Color by (optional):",
            [None] + filtered_data.columns.tolist(),
            key="custom_color"
        )
        
        chart_title = st.text_input("Chart Title:", value=f"{chart_type.title()} Chart", key="custom_title")
        
        if st.button("Generate Custom Chart"):
            if x_column and y_column:
                try:
                    custom_fig = create_custom_chart(
                        filtered_data,
                        chart_type,
                        x_column,
                        y_column,
                        color_column,
                        chart_title
                    )
                    st.plotly_chart(custom_fig, use_container_width=True)
                except Exception as e:
                    st.error(f"Error creating chart: {str(e)}")
    
    # Statistical insights
    st.markdown("---")
    st.subheader("📋 Statistical Insights")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("**Correlation Analysis**")
        
        pollutant_cols = ['PM2.5', 'PM10', 'NO2', 'SO2', 'O3', 'AQI']
        available_pollutants = [col for col in pollutant_cols if col in filtered_data.columns]
        
        if len(available_pollutants) > 1:
            corr_matrix = filtered_data[available_pollutants].corr()
            
            # Find strongest correlations
            correlations = []
            for i in range(len(corr_matrix.columns)):
                for j in range(i+1, len(corr_matrix.columns)):
                    correlations.append({
                        'Pollutant_1': corr_matrix.columns[i],
                        'Pollutant_2': corr_matrix.columns[j],
                        'Correlation': corr_matrix.iloc[i, j]
                    })
            
            corr_df = pd.DataFrame(correlations).sort_values('Correlation', key=abs, ascending=False)
            st.dataframe(corr_df.head(10), use_container_width=True)
    
    with col2:
        st.write("**Key Statistics**")
        
        if not filtered_data.empty:
            # Calculate some interesting statistics
            stats = {
                'Highest AQI Day': f"{filtered_data.loc[filtered_data['AQI'].idxmax(), 'Date'].strftime('%Y-%m-%d')} ({filtered_data['AQI'].max():.1f})",
                'Most Polluted City': filtered_data.groupby('City')['AQI'].mean().idxmax(),
                'Cleanest City': filtered_data.groupby('City')['AQI'].mean().idxmin(),
                'Days with Good Air': len(filtered_data[filtered_data['AQI'] <= 50]),
                'Days with Poor Air': len(filtered_data[filtered_data['AQI'] > 200])
            }
            
            for key, value in stats.items():
                st.write(f"**{key}:** {value}")

if __name__ == "__main__":
    main()
