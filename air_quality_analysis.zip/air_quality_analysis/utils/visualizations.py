import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import streamlit as st

# Color schemes for different visualizations
AQI_COLORS = {
    'Good': '#00e400',
    'Satisfactory': '#ffff00',
    'Moderate': '#ff7e00',
    'Poor': '#ff0000',
    'Very Poor': '#8f3f97',
    'Severe': '#7e0023'
}

POLLUTANT_COLORS = {
    'PM2.5': '#ff6b6b',
    'PM10': '#4ecdc4',
    'NO2': '#45b7d1',
    'SO2': '#96ceb4',
    'O3': '#feca57',
    'CO': '#ff9ff3',
    'AQI': '#54a0ff'
}

def create_overview_charts(df):
    """
    Create overview charts for the main dashboard
    
    Args:
        df (pd.DataFrame): The dataframe
        
    Returns:
        dict: Dictionary containing plotly figures
    """
    charts = {}
    
    # 1. AQI Trend Over Time
    daily_aqi = df.groupby('Date')['AQI'].mean().reset_index()
    
    fig_trend = go.Figure()
    fig_trend.add_trace(go.Scatter(
        x=daily_aqi['Date'],
        y=daily_aqi['AQI'],
        mode='lines',
        name='Average AQI',
        line=dict(color='#1f77b4', width=2),
        fill='tonexty'
    ))
    
    fig_trend.update_layout(
        title='AQI Trend Over Time',
        xaxis_title='Date',
        yaxis_title='AQI',
        template='plotly_white',
        height=400
    )
    
    charts['aqi_trend'] = fig_trend
    
    # 2. Pollutant Correlation Heatmap
    pollutants = ['PM2.5', 'PM10', 'NO2', 'SO2', 'O3', 'AQI']
    available_pollutants = [col for col in pollutants if col in df.columns]
    
    if len(available_pollutants) > 1:
        corr_matrix = df[available_pollutants].corr()
        
        fig_corr = go.Figure(data=go.Heatmap(
            z=corr_matrix.values,
            x=corr_matrix.columns,
            y=corr_matrix.columns,
            colorscale='RdBu',
            zmid=0,
            text=corr_matrix.round(2).values,
            texttemplate='%{text}',
            textfont={"size": 10},
            showscale=True
        ))
        
        fig_corr.update_layout(
            title='Pollutant Correlation Matrix',
            template='plotly_white',
            height=400
        )
        
        charts['pollutant_correlation'] = fig_corr
    
    # 3. City Comparison (Top 10 cities by average AQI)
    city_aqi = df.groupby('City')['AQI'].mean().sort_values(ascending=False).head(10)
    
    fig_cities = px.bar(
        x=city_aqi.index,
        y=city_aqi.values,
        title='Top 10 Cities by Average AQI',
        labels={'x': 'City', 'y': 'Average AQI'},
        color=city_aqi.values,
        color_continuous_scale='Reds'
    )
    
    fig_cities.update_layout(
        template='plotly_white',
        height=400,
        xaxis={'tickangle': 45}
    )
    
    charts['city_comparison'] = fig_cities
    
    return charts

def create_time_series_charts(df):
    """
    Create advanced time series visualizations
    
    Args:
        df (pd.DataFrame): The dataframe
        
    Returns:
        dict: Dictionary containing plotly figures
    """
    charts = {}
    
    # 1. Multi-pollutant time series
    pollutants = ['PM2.5', 'PM10', 'NO2', 'SO2', 'O3']
    available_pollutants = [col for col in pollutants if col in df.columns]
    
    if available_pollutants:
        daily_data = df.groupby('Date')[available_pollutants].mean().reset_index()
        
        fig_multi = go.Figure()
        
        for pollutant in available_pollutants:
            fig_multi.add_trace(go.Scatter(
                x=daily_data['Date'],
                y=daily_data[pollutant],
                mode='lines',
                name=pollutant,
                line=dict(color=POLLUTANT_COLORS.get(pollutant, '#1f77b4'))
            ))
        
        fig_multi.update_layout(
            title='Multi-Pollutant Trends Over Time',
            xaxis_title='Date',
            yaxis_title='Concentration (μg/m³)',
            template='plotly_white',
            height=500,
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
        )
        
        charts['multi_pollutant'] = fig_multi
    
    # 2. Seasonal decomposition visualization
    if 'AQI' in df.columns:
        monthly_aqi = df.groupby(df['Date'].dt.to_period('M'))['AQI'].mean()
        
        fig_seasonal = go.Figure()
        fig_seasonal.add_trace(go.Scatter(
            x=[str(period) for period in monthly_aqi.index],
            y=monthly_aqi.values,
            mode='lines+markers',
            name='Monthly AQI',
            line=dict(color='#ff6b6b', width=3),
            marker=dict(size=8)
        ))
        
        fig_seasonal.update_layout(
            title='Monthly AQI Trends',
            xaxis_title='Month',
            yaxis_title='Average AQI',
            template='plotly_white',
            height=400
        )
        
        charts['seasonal'] = fig_seasonal
    
    # 3. Heatmap by month and year
    if 'Year' in df.columns and 'Month' in df.columns:
        heatmap_data = df.groupby(['Year', 'Month'])['AQI'].mean().unstack(fill_value=0)
        
        fig_heatmap = go.Figure(data=go.Heatmap(
            z=heatmap_data.values,
            x=[f'Month {i}' for i in heatmap_data.columns],
            y=heatmap_data.index,
            colorscale='YlOrRd',
            showscale=True,
            colorbar=dict(title='Average AQI')
        ))
        
        fig_heatmap.update_layout(
            title='AQI Heatmap by Year and Month',
            xaxis_title='Month',
            yaxis_title='Year',
            template='plotly_white',
            height=400
        )
        
        charts['yearly_heatmap'] = fig_heatmap
    
    return charts

def create_geographical_charts(df):
    """
    Create geographical visualizations
    
    Args:
        df (pd.DataFrame): The dataframe
        
    Returns:
        dict: Dictionary containing plotly figures
    """
    charts = {}
    
    # City-wise statistics
    city_stats = df.groupby('City').agg({
        'AQI': ['mean', 'max', 'min'],
        'PM2.5': 'mean',
        'PM10': 'mean'
    }).round(2)
    
    city_stats.columns = ['AQI_Mean', 'AQI_Max', 'AQI_Min', 'PM2.5_Mean', 'PM10_Mean']
    city_stats = city_stats.reset_index()
    
    # Bubble chart for cities
    fig_bubble = px.scatter(
        city_stats,
        x='PM2.5_Mean',
        y='PM10_Mean',
        size='AQI_Mean',
        color='AQI_Mean',
        hover_name='City',
        title='City Comparison: PM2.5 vs PM10 (Bubble size = Average AQI)',
        labels={'PM2.5_Mean': 'Average PM2.5 (μg/m³)', 'PM10_Mean': 'Average PM10 (μg/m³)'},
        color_continuous_scale='Reds',
        size_max=60
    )
    
    fig_bubble.update_layout(
        template='plotly_white',
        height=500
    )
    
    charts['city_bubble'] = fig_bubble
    
    return charts

def create_distribution_charts(df):
    """
    Create distribution and statistical visualizations
    
    Args:
        df (pd.DataFrame): The dataframe
        
    Returns:
        dict: Dictionary containing plotly figures
    """
    charts = {}
    
    # 1. AQI distribution histogram
    fig_hist = px.histogram(
        df,
        x='AQI',
        nbins=50,
        title='AQI Distribution',
        labels={'count': 'Frequency', 'AQI': 'AQI Value'},
        color_discrete_sequence=['#1f77b4']
    )
    
    fig_hist.update_layout(
        template='plotly_white',
        height=400
    )
    
    charts['aqi_distribution'] = fig_hist
    
    # 2. Box plots for pollutants by season
    if 'Season' in df.columns:
        pollutants = ['PM2.5', 'PM10', 'NO2', 'AQI']
        available_pollutants = [col for col in pollutants if col in df.columns]
        
        if available_pollutants:
            fig_box = make_subplots(
                rows=2, cols=2,
                subplot_titles=available_pollutants[:4],
                vertical_spacing=0.1
            )
            
            positions = [(1, 1), (1, 2), (2, 1), (2, 2)]
            
            for i, pollutant in enumerate(available_pollutants[:4]):
                row, col = positions[i]
                
                for season in df['Season'].unique():
                    season_data = df[df['Season'] == season][pollutant]
                    fig_box.add_trace(
                        go.Box(y=season_data, name=season, showlegend=(i == 0)),
                        row=row, col=col
                    )
            
            fig_box.update_layout(
                title='Pollutant Distributions by Season',
                template='plotly_white',
                height=600
            )
            
            charts['seasonal_box'] = fig_box
    
    # 3. Violin plots for AQI by city (top 10 cities)
    top_cities = df['City'].value_counts().head(10).index
    df_top_cities = df[df['City'].isin(top_cities)]
    
    fig_violin = px.violin(
        df_top_cities,
        x='City',
        y='AQI',
        title='AQI Distribution by City (Top 10 by Data Points)',
        color='City'
    )
    
    fig_violin.update_layout(
        template='plotly_white',
        height=400,
        xaxis={'tickangle': 45},
        showlegend=False
    )
    
    charts['city_violin'] = fig_violin
    
    return charts

def create_advanced_analytics_charts(df):
    """
    Create advanced analytics visualizations
    
    Args:
        df (pd.DataFrame): The dataframe
        
    Returns:
        dict: Dictionary containing plotly figures
    """
    charts = {}
    
    # 1. Pollutant ratios analysis
    if all(col in df.columns for col in ['PM2.5', 'PM10']):
        df_temp = df.copy()
        df_temp['PM2.5_to_PM10_ratio'] = df_temp['PM2.5'] / df_temp['PM10']
        df_temp = df_temp.dropna(subset=['PM2.5_to_PM10_ratio'])
        
        fig_ratio = px.scatter(
            df_temp,
            x='PM10',
            y='PM2.5',
            color='AQI',
            title='PM2.5 vs PM10 Relationship',
            labels={'PM10': 'PM10 (μg/m³)', 'PM2.5': 'PM2.5 (μg/m³)'},
            color_continuous_scale='Viridis'
        )
        
        # Add diagonal line for reference
        max_val = max(df_temp['PM10'].max(), df_temp['PM2.5'].max())
        fig_ratio.add_trace(go.Scatter(
            x=[0, max_val],
            y=[0, max_val],
            mode='lines',
            name='PM2.5 = PM10',
            line=dict(dash='dash', color='red')
        ))
        
        fig_ratio.update_layout(
            template='plotly_white',
            height=500
        )
        
        charts['pm_ratio'] = fig_ratio
    
    # 2. Monthly trends comparison
    if 'Month' in df.columns:
        monthly_stats = df.groupby('Month').agg({
            'AQI': ['mean', 'std'],
            'PM2.5': 'mean',
            'PM10': 'mean'
        }).round(2)
        
        monthly_stats.columns = ['AQI_Mean', 'AQI_Std', 'PM2.5_Mean', 'PM10_Mean']
        monthly_stats = monthly_stats.reset_index()
        
        fig_monthly = make_subplots(
            rows=2, cols=1,
            subplot_titles=['Average AQI by Month', 'Average PM Levels by Month'],
            shared_xaxes=True
        )
        
        # AQI with error bars
        fig_monthly.add_trace(
            go.Scatter(
                x=monthly_stats['Month'],
                y=monthly_stats['AQI_Mean'],
                error_y=dict(type='data', array=monthly_stats['AQI_Std']),
                mode='lines+markers',
                name='AQI',
                line=dict(color='#ff6b6b')
            ),
            row=1, col=1
        )
        
        # PM levels
        fig_monthly.add_trace(
            go.Scatter(
                x=monthly_stats['Month'],
                y=monthly_stats['PM2.5_Mean'],
                mode='lines+markers',
                name='PM2.5',
                line=dict(color='#4ecdc4')
            ),
            row=2, col=1
        )
        
        fig_monthly.add_trace(
            go.Scatter(
                x=monthly_stats['Month'],
                y=monthly_stats['PM10_Mean'],
                mode='lines+markers',
                name='PM10',
                line=dict(color='#45b7d1')
            ),
            row=2, col=1
        )
        
        fig_monthly.update_layout(
            title='Monthly Air Quality Trends',
            template='plotly_white',
            height=600
        )
        
        charts['monthly_trends'] = fig_monthly
    
    return charts

def create_custom_chart(df, chart_type, x_col, y_col, color_col=None, title=None):
    """
    Create a custom chart based on user specifications
    
    Args:
        df (pd.DataFrame): The dataframe
        chart_type (str): Type of chart ('scatter', 'line', 'bar', 'box')
        x_col (str): X-axis column
        y_col (str): Y-axis column
        color_col (str): Color column (optional)
        title (str): Chart title (optional)
        
    Returns:
        plotly.graph_objects.Figure: The custom chart
    """
    if title is None:
        title = f'{chart_type.title()} Chart: {y_col} vs {x_col}'
    
    if chart_type == 'scatter':
        fig = px.scatter(df, x=x_col, y=y_col, color=color_col, title=title)
    elif chart_type == 'line':
        fig = px.line(df, x=x_col, y=y_col, color=color_col, title=title)
    elif chart_type == 'bar':
        fig = px.bar(df, x=x_col, y=y_col, color=color_col, title=title)
    elif chart_type == 'box':
        fig = px.box(df, x=x_col, y=y_col, color=color_col, title=title)
    else:
        # Default to scatter
        fig = px.scatter(df, x=x_col, y=y_col, color=color_col, title=title)
    
    fig.update_layout(template='plotly_white', height=500)
    
    return fig
