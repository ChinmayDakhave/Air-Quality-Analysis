import pandas as pd
import numpy as np
import streamlit as st
from datetime import datetime
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@st.cache_data
def load_and_preprocess_data(file_path):
    """
    Load and preprocess the air quality data
    
    Args:
        file_path (str): Path to the CSV file
        
    Returns:
        pd.DataFrame: Preprocessed dataframe
    """
    try:
        # Load data
        df = pd.read_csv(file_path)
        logger.info(f"Loaded data with shape: {df.shape}")
        
        # Convert Date column to datetime
        df['Date'] = pd.to_datetime(df['Date'])
        
        # Handle missing values
        numeric_columns = ['PM2.5', 'PM10', 'NO', 'NO2', 'NOx', 'NH3', 'CO', 'SO2', 'O3', 'Benzene', 'Toluene', 'AQI']
        
        # Replace zeros and negative values with NaN for certain pollutants
        for col in numeric_columns:
            if col in df.columns:
                df.loc[df[col] <= 0, col] = np.nan
        
        # Fill missing values with median for each city
        for city in df['City'].unique():
            city_mask = df['City'] == city
            for col in numeric_columns:
                if col in df.columns:
                    median_val = df.loc[city_mask, col].median()
                    df.loc[city_mask & df[col].isna(), col] = median_val
        
        # Create additional features
        df['Year'] = df['Date'].dt.year
        df['Month'] = df['Date'].dt.month
        df['Quarter'] = df['Date'].dt.quarter
        df['DayOfWeek'] = df['Date'].dt.dayofweek
        df['Season'] = df['Month'].map({
            12: 'Winter', 1: 'Winter', 2: 'Winter',
            3: 'Spring', 4: 'Spring', 5: 'Spring',
            6: 'Summer', 7: 'Summer', 8: 'Summer',
            9: 'Autumn', 10: 'Autumn', 11: 'Autumn'
        })
        
        # Create AQI severity score
        aqi_severity_map = {
            'Good': 1,
            'Satisfactory': 2,
            'Moderate': 3,
            'Poor': 4,
            'Very Poor': 5,
            'Severe': 6
        }
        df['AQI_Severity'] = df['AQI_Bucket'].map(aqi_severity_map)
        
        # Calculate composite pollution index
        pollutants = ['PM2.5', 'PM10', 'NO2', 'SO2', 'O3', 'CO']
        available_pollutants = [col for col in pollutants if col in df.columns]
        
        if available_pollutants:
            # Normalize pollutants (0-1 scale)
            df_norm = df[available_pollutants].copy()
            for col in available_pollutants:
                max_val = df_norm[col].max()
                if max_val > 0:
                    df_norm[col] = df_norm[col] / max_val
            
            df['Composite_Pollution_Index'] = df_norm[available_pollutants].mean(axis=1)
        
        # Remove rows with too many missing values
        df = df.dropna(subset=['City', 'Date', 'AQI'], how='any')
        
        logger.info(f"Processed data with shape: {df.shape}")
        return df
        
    except Exception as e:
        logger.error(f"Error loading data: {str(e)}")
        st.error(f"Error loading data: {str(e)}")
        return None

def get_data_summary(df):
    """
    Get summary statistics of the dataset
    
    Args:
        df (pd.DataFrame): The dataframe to summarize
        
    Returns:
        dict: Summary statistics
    """
    if df is None or df.empty:
        return {}
    
    summary = {
        'total_records': len(df),
        'cities_count': df['City'].nunique(),
        'date_range': {
            'start': df['Date'].min().strftime('%Y-%m-%d'),
            'end': df['Date'].max().strftime('%Y-%m-%d')
        },
        'pollutants_count': len([col for col in df.columns if col in ['PM2.5', 'PM10', 'NO', 'NO2', 'NOx', 'NH3', 'CO', 'SO2', 'O3', 'Benzene', 'Toluene']]),
        'aqi_stats': {
            'mean': df['AQI'].mean(),
            'min': df['AQI'].min(),
            'max': df['AQI'].max(),
            'std': df['AQI'].std()
        },
        'missing_data_percentage': (df.isnull().sum() / len(df) * 100).to_dict()
    }
    
    return summary

def get_city_statistics(df, city_name):
    """
    Get detailed statistics for a specific city
    
    Args:
        df (pd.DataFrame): The dataframe
        city_name (str): Name of the city
        
    Returns:
        dict: City-specific statistics
    """
    city_data = df[df['City'] == city_name].copy()
    
    if city_data.empty:
        return {}
    
    numeric_columns = ['PM2.5', 'PM10', 'NO', 'NO2', 'NOx', 'NH3', 'CO', 'SO2', 'O3', 'Benzene', 'Toluene', 'AQI']
    available_columns = [col for col in numeric_columns if col in city_data.columns]
    
    stats = {}
    for col in available_columns:
        stats[col] = {
            'mean': city_data[col].mean(),
            'median': city_data[col].median(),
            'std': city_data[col].std(),
            'min': city_data[col].min(),
            'max': city_data[col].max(),
            'percentile_25': city_data[col].quantile(0.25),
            'percentile_75': city_data[col].quantile(0.75)
        }
    
    # AQI bucket distribution
    aqi_distribution = city_data['AQI_Bucket'].value_counts(normalize=True) * 100
    
    return {
        'pollutant_stats': stats,
        'aqi_distribution': aqi_distribution.to_dict(),
        'total_records': len(city_data),
        'date_range': {
            'start': city_data['Date'].min().strftime('%Y-%m-%d'),
            'end': city_data['Date'].max().strftime('%Y-%m-%d')
        }
    }

def filter_data_by_conditions(df, conditions):
    """
    Filter data based on multiple conditions
    
    Args:
        df (pd.DataFrame): The dataframe to filter
        conditions (dict): Dictionary of filter conditions
        
    Returns:
        pd.DataFrame: Filtered dataframe
    """
    filtered_df = df.copy()
    
    if 'cities' in conditions and conditions['cities']:
        filtered_df = filtered_df[filtered_df['City'].isin(conditions['cities'])]
    
    if 'date_range' in conditions and len(conditions['date_range']) == 2:
        start_date, end_date = conditions['date_range']
        filtered_df = filtered_df[
            (filtered_df['Date'] >= pd.to_datetime(start_date)) &
            (filtered_df['Date'] <= pd.to_datetime(end_date))
        ]
    
    if 'aqi_range' in conditions and len(conditions['aqi_range']) == 2:
        min_aqi, max_aqi = conditions['aqi_range']
        filtered_df = filtered_df[
            (filtered_df['AQI'] >= min_aqi) &
            (filtered_df['AQI'] <= max_aqi)
        ]
    
    if 'seasons' in conditions and conditions['seasons']:
        filtered_df = filtered_df[filtered_df['Season'].isin(conditions['seasons'])]
    
    if 'aqi_buckets' in conditions and conditions['aqi_buckets']:
        filtered_df = filtered_df[filtered_df['AQI_Bucket'].isin(conditions['aqi_buckets'])]
    
    return filtered_df

def get_pollutant_correlations(df):
    """
    Calculate correlations between pollutants
    
    Args:
        df (pd.DataFrame): The dataframe
        
    Returns:
        pd.DataFrame: Correlation matrix
    """
    pollutant_columns = ['PM2.5', 'PM10', 'NO', 'NO2', 'NOx', 'NH3', 'CO', 'SO2', 'O3', 'Benzene', 'Toluene', 'AQI']
    available_columns = [col for col in pollutant_columns if col in df.columns]
    
    correlation_matrix = df[available_columns].corr()
    return correlation_matrix
