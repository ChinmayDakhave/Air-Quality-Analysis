import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.preprocessing import StandardScaler, LabelEncoder
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import streamlit as st
import warnings
warnings.filterwarnings('ignore')

class AirQualityPredictor:
    """
    Advanced machine learning models for air quality prediction
    """
    
    def __init__(self):
        self.models = {
            'Random Forest': RandomForestRegressor(n_estimators=100, random_state=42),
            'Gradient Boosting': GradientBoostingRegressor(n_estimators=100, random_state=42),
            'Linear Regression': LinearRegression(),
            'Ridge Regression': Ridge(alpha=1.0),
            'Lasso Regression': Lasso(alpha=1.0),
            'Support Vector Regression': SVR(kernel='rbf', C=1.0)
        }
        self.scaler = StandardScaler()
        self.label_encoder = LabelEncoder()
        self.trained_models = {}
        self.feature_importance = {}
        self.performance_metrics = {}
    
    def prepare_features(self, df, target_column='AQI'):
        """
        Prepare features for machine learning
        
        Args:
            df (pd.DataFrame): The dataframe
            target_column (str): Target variable column name
            
        Returns:
            tuple: (X, y, feature_names)
        """
        # Create a copy to avoid modifying original data
        data = df.copy()
        
        # Handle missing values
        data = data.dropna(subset=[target_column])
        
        # Select features
        feature_columns = []
        
        # Numeric pollutant features
        pollutant_features = ['PM2.5', 'PM10', 'NO', 'NO2', 'NOx', 'NH3', 'CO', 'SO2', 'O3', 'Benzene', 'Toluene']
        for col in pollutant_features:
            if col in data.columns and col != target_column:
                feature_columns.append(col)
        
        # Temporal features
        if 'Date' in data.columns:
            data['Year'] = data['Date'].dt.year
            data['Month'] = data['Date'].dt.month
            data['DayOfWeek'] = data['Date'].dt.dayofweek
            data['Quarter'] = data['Date'].dt.quarter
            feature_columns.extend(['Year', 'Month', 'DayOfWeek', 'Quarter'])
        
        # Categorical features
        if 'City' in data.columns:
            # Encode city as numeric
            city_encoded = self.label_encoder.fit_transform(data['City'])
            data['City_Encoded'] = city_encoded
            feature_columns.append('City_Encoded')
        
        if 'Season' in data.columns:
            season_dummies = pd.get_dummies(data['Season'], prefix='Season')
            data = pd.concat([data, season_dummies], axis=1)
            feature_columns.extend(season_dummies.columns.tolist())
        
        # Remove rows with missing features
        data = data.dropna(subset=feature_columns + [target_column])
        
        X = data[feature_columns]
        y = data[target_column]
        
        return X, y, feature_columns
    
    def train_models(self, X, y):
        """
        Train multiple machine learning models
        
        Args:
            X (pd.DataFrame): Features
            y (pd.Series): Target variable
            
        Returns:
            dict: Performance metrics for each model
        """
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        # Scale features for models that need it
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        
        performance = {}
        
        for name, model in self.models.items():
            try:
                # Use scaled data for SVM and linear models
                if name in ['Support Vector Regression', 'Ridge Regression', 'Lasso Regression']:
                    model.fit(X_train_scaled, y_train)
                    y_pred = model.predict(X_test_scaled)
                    
                    # Cross-validation
                    cv_scores = cross_val_score(model, X_train_scaled, y_train, cv=5, scoring='r2')
                else:
                    model.fit(X_train, y_train)
                    y_pred = model.predict(X_test)
                    
                    # Cross-validation
                    cv_scores = cross_val_score(model, X_train, y_train, cv=5, scoring='r2')
                
                # Calculate metrics
                mse = mean_squared_error(y_test, y_pred)
                mae = mean_absolute_error(y_test, y_pred)
                r2 = r2_score(y_test, y_pred)
                rmse = np.sqrt(mse)
                
                performance[name] = {
                    'MSE': mse,
                    'MAE': mae,
                    'RMSE': rmse,
                    'R2': r2,
                    'CV_R2_Mean': cv_scores.mean(),
                    'CV_R2_Std': cv_scores.std(),
                    'Predictions': y_pred,
                    'Actual': y_test.values
                }
                
                # Store trained model
                self.trained_models[name] = model
                
                # Feature importance for tree-based models
                if hasattr(model, 'feature_importances_'):
                    self.feature_importance[name] = dict(zip(X.columns, model.feature_importances_))
                
            except Exception as e:
                st.error(f"Error training {name}: {str(e)}")
                continue
        
        self.performance_metrics = performance
        return performance
    
    def create_prediction_visualizations(self):
        """
        Create visualizations for model predictions
        
        Returns:
            dict: Dictionary containing plotly figures
        """
        charts = {}
        
        # 1. Model Performance Comparison
        if self.performance_metrics:
            metrics_df = pd.DataFrame({
                model: {
                    'R² Score': metrics['R2'],
                    'RMSE': metrics['RMSE'],
                    'MAE': metrics['MAE']
                }
                for model, metrics in self.performance_metrics.items()
            }).T
            
            # R² Score comparison
            fig_r2 = px.bar(
                x=metrics_df.index,
                y=metrics_df['R² Score'],
                title='Model Performance Comparison (R² Score)',
                labels={'x': 'Model', 'y': 'R² Score'},
                color=metrics_df['R² Score'],
                color_continuous_scale='Viridis'
            )
            fig_r2.update_layout(template='plotly_white', height=400)
            charts['model_performance'] = fig_r2
            
            # RMSE comparison
            fig_rmse = px.bar(
                x=metrics_df.index,
                y=metrics_df['RMSE'],
                title='Model Performance Comparison (RMSE)',
                labels={'x': 'Model', 'y': 'RMSE'},
                color=metrics_df['RMSE'],
                color_continuous_scale='Reds'
            )
            fig_rmse.update_layout(template='plotly_white', height=400)
            charts['model_rmse'] = fig_rmse
        
        # 2. Actual vs Predicted plots
        if self.performance_metrics:
            best_model = max(self.performance_metrics.keys(), 
                           key=lambda x: self.performance_metrics[x]['R2'])
            
            actual = self.performance_metrics[best_model]['Actual']
            predicted = self.performance_metrics[best_model]['Predictions']
            
            fig_pred = go.Figure()
            
            # Scatter plot
            fig_pred.add_trace(go.Scatter(
                x=actual,
                y=predicted,
                mode='markers',
                name='Predictions',
                marker=dict(color='blue', opacity=0.6)
            ))
            
            # Perfect prediction line
            min_val = min(actual.min(), predicted.min())
            max_val = max(actual.max(), predicted.max())
            fig_pred.add_trace(go.Scatter(
                x=[min_val, max_val],
                y=[min_val, max_val],
                mode='lines',
                name='Perfect Prediction',
                line=dict(color='red', dash='dash')
            ))
            
            fig_pred.update_layout(
                title=f'Actual vs Predicted AQI ({best_model})',
                xaxis_title='Actual AQI',
                yaxis_title='Predicted AQI',
                template='plotly_white',
                height=500
            )
            
            charts['actual_vs_predicted'] = fig_pred
        
        # 3. Feature Importance (for tree-based models)
        if self.feature_importance:
            for model_name, importance in self.feature_importance.items():
                importance_df = pd.DataFrame(list(importance.items()), 
                                           columns=['Feature', 'Importance'])
                importance_df = importance_df.sort_values('Importance', ascending=True).tail(10)
                
                fig_importance = px.bar(
                    importance_df,
                    x='Importance',
                    y='Feature',
                    orientation='h',
                    title=f'Feature Importance ({model_name})',
                    color='Importance',
                    color_continuous_scale='Viridis'
                )
                fig_importance.update_layout(template='plotly_white', height=500)
                charts[f'feature_importance_{model_name.lower().replace(" ", "_")}'] = fig_importance
        
        return charts
    
    def predict_future_aqi(self, df, days_ahead=30):
        """
        Predict future AQI values
        
        Args:
            df (pd.DataFrame): Historical data
            days_ahead (int): Number of days to predict ahead
            
        Returns:
            pd.DataFrame: Future predictions
        """
        if not self.trained_models:
            st.error("No trained models available. Please train models first.")
            return None
        
        # Get the best performing model
        best_model_name = max(self.performance_metrics.keys(), 
                            key=lambda x: self.performance_metrics[x]['R2'])
        best_model = self.trained_models[best_model_name]
        
        # Prepare features for prediction
        X, y, feature_names = self.prepare_features(df)
        
        # Get the last known values
        last_row = df.iloc[-1].copy()
        last_date = pd.to_datetime(last_row['Date'])
        
        predictions = []
        dates = []
        
        for i in range(1, days_ahead + 1):
            future_date = last_date + pd.Timedelta(days=i)
            
            # Create feature vector for future prediction
            future_features = []
            
            for feature in feature_names:
                if feature in ['Year', 'Month', 'DayOfWeek', 'Quarter']:
                    if feature == 'Year':
                        future_features.append(future_date.year)
                    elif feature == 'Month':
                        future_features.append(future_date.month)
                    elif feature == 'DayOfWeek':
                        future_features.append(future_date.dayofweek)
                    elif feature == 'Quarter':
                        future_features.append(future_date.quarter)
                elif feature.startswith('Season_'):
                    # Season encoding
                    season = 'Winter' if future_date.month in [12, 1, 2] else \
                            'Spring' if future_date.month in [3, 4, 5] else \
                            'Summer' if future_date.month in [6, 7, 8] else 'Autumn'
                    future_features.append(1 if feature == f'Season_{season}' else 0)
                else:
                    # Use last known value for pollutants
                    if feature in df.columns:
                        future_features.append(last_row[feature])
                    else:
                        future_features.append(0)
            
            # Make prediction
            if best_model_name in ['Support Vector Regression', 'Ridge Regression', 'Lasso Regression']:
                future_features_scaled = self.scaler.transform([future_features])
                pred = best_model.predict(future_features_scaled)[0]
            else:
                pred = best_model.predict([future_features])[0]
            
            predictions.append(pred)
            dates.append(future_date)
        
        future_df = pd.DataFrame({
            'Date': dates,
            'Predicted_AQI': predictions,
            'Model': best_model_name
        })
        
        return future_df

def create_model_comparison_chart(performance_metrics):
    """
    Create a comprehensive model comparison chart
    
    Args:
        performance_metrics (dict): Performance metrics for all models
        
    Returns:
        plotly.graph_objects.Figure: Comparison chart
    """
    models = list(performance_metrics.keys())
    r2_scores = [performance_metrics[model]['R2'] for model in models]
    rmse_scores = [performance_metrics[model]['RMSE'] for model in models]
    mae_scores = [performance_metrics[model]['MAE'] for model in models]
    
    fig = make_subplots(
        rows=1, cols=3,
        subplot_titles=['R² Score', 'RMSE', 'MAE'],
        specs=[[{"secondary_y": False}, {"secondary_y": False}, {"secondary_y": False}]]
    )
    
    # R² Score
    fig.add_trace(
        go.Bar(x=models, y=r2_scores, name='R² Score', marker_color='blue'),
        row=1, col=1
    )
    
    # RMSE
    fig.add_trace(
        go.Bar(x=models, y=rmse_scores, name='RMSE', marker_color='red'),
        row=1, col=2
    )
    
    # MAE
    fig.add_trace(
        go.Bar(x=models, y=mae_scores, name='MAE', marker_color='green'),
        row=1, col=3
    )
    
    fig.update_layout(
        title='Comprehensive Model Performance Comparison',
        template='plotly_white',
        height=500,
        showlegend=False
    )
    
    return fig

def create_residual_analysis(actual, predicted, model_name):
    """
    Create residual analysis plots
    
    Args:
        actual (array): Actual values
        predicted (array): Predicted values
        model_name (str): Name of the model
        
    Returns:
        plotly.graph_objects.Figure: Residual analysis chart
    """
    residuals = actual - predicted
    
    fig = make_subplots(
        rows=1, cols=2,
        subplot_titles=['Residuals vs Predicted', 'Residuals Distribution'],
        specs=[[{"secondary_y": False}, {"secondary_y": False}]]
    )
    
    # Residuals vs Predicted
    fig.add_trace(
        go.Scatter(
            x=predicted,
            y=residuals,
            mode='markers',
            name='Residuals',
            marker=dict(color='blue', opacity=0.6)
        ),
        row=1, col=1
    )
    
    # Add zero line
    fig.add_hline(y=0, line_dash="dash", line_color="red", row=1, col=1)
    
    # Residuals histogram
    fig.add_trace(
        go.Histogram(
            x=residuals,
            name='Residuals Distribution',
            marker_color='lightblue',
            opacity=0.7
        ),
        row=1, col=2
    )
    
    fig.update_layout(
        title=f'Residual Analysis for {model_name}',
        template='plotly_white',
        height=400,
        showlegend=False
    )
    
    return fig
