import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import streamlit as st

# WHO Air Quality Guidelines and health impact thresholds
WHO_GUIDELINES = {
    'PM2.5': {
        'annual_mean': 5,  # µg/m³
        'daily_mean': 15,  # µg/m³
        'health_categories': {
            'Good': (0, 12),
            'Moderate': (12.1, 35.4),
            'Unhealthy for Sensitive': (35.5, 55.4),
            'Unhealthy': (55.5, 150.4),
            'Very Unhealthy': (150.5, 250.4),
            'Hazardous': (250.5, float('inf'))
        }
    },
    'PM10': {
        'annual_mean': 15,  # µg/m³
        'daily_mean': 45,  # µg/m³
        'health_categories': {
            'Good': (0, 54),
            'Moderate': (55, 154),
            'Unhealthy for Sensitive': (155, 254),
            'Unhealthy': (255, 354),
            'Very Unhealthy': (355, 424),
            'Hazardous': (425, float('inf'))
        }
    },
    'NO2': {
        'annual_mean': 10,  # µg/m³
        'daily_mean': 25,  # µg/m³
    },
    'O3': {
        '8_hour_mean': 60,  # µg/m³
    },
    'SO2': {
        'daily_mean': 40,  # µg/m³
    }
}

HEALTH_IMPACT_FACTORS = {
    'PM2.5': {
        'respiratory_disease_risk': 1.04,  # 4% increase per 10 µg/m³
        'cardiovascular_disease_risk': 1.06,  # 6% increase per 10 µg/m³
        'premature_mortality_risk': 1.08,  # 8% increase per 10 µg/m³
        'asthma_exacerbation': 1.03  # 3% increase per 10 µg/m³
    },
    'PM10': {
        'respiratory_disease_risk': 1.02,  # 2% increase per 10 µg/m³
        'cardiovascular_disease_risk': 1.03,  # 3% increase per 10 µg/m³
    },
    'NO2': {
        'respiratory_disease_risk': 1.05,  # 5% increase per 10 µg/m³
        'asthma_development': 1.15,  # 15% increase per 10 µg/m³
    },
    'O3': {
        'respiratory_disease_risk': 1.03,  # 3% increase per 10 µg/m³
        'premature_mortality_risk': 1.04,  # 4% increase per 10 µg/m³
    }
}

class HealthImpactCalculator:
    """
    Calculate health impacts and risks based on air quality data
    """
    
    def __init__(self):
        self.who_guidelines = WHO_GUIDELINES
        self.health_factors = HEALTH_IMPACT_FACTORS
    
    def calculate_health_risk_scores(self, df):
        """
        Calculate comprehensive health risk scores for each record
        
        Args:
            df (pd.DataFrame): Air quality dataframe
            
        Returns:
            pd.DataFrame: Dataframe with health risk scores
        """
        df_health = df.copy()
        
        # Initialize risk scores
        df_health['Respiratory_Risk_Score'] = 0
        df_health['Cardiovascular_Risk_Score'] = 0
        df_health['Overall_Health_Risk'] = 0
        df_health['Vulnerable_Population_Risk'] = 0
        
        # Calculate risks for each pollutant
        for pollutant in ['PM2.5', 'PM10', 'NO2', 'O3', 'SO2']:
            if pollutant in df_health.columns:
                pollutant_levels = df_health[pollutant].fillna(0)
                
                if pollutant in self.health_factors:
                    factors = self.health_factors[pollutant]
                    
                    # Respiratory risk
                    if 'respiratory_disease_risk' in factors:
                        risk_factor = factors['respiratory_disease_risk']
                        df_health['Respiratory_Risk_Score'] += (pollutant_levels / 10) * (risk_factor - 1) * 100
                    
                    # Cardiovascular risk
                    if 'cardiovascular_disease_risk' in factors:
                        risk_factor = factors['cardiovascular_disease_risk']
                        df_health['Cardiovascular_Risk_Score'] += (pollutant_levels / 10) * (risk_factor - 1) * 100
        
        # Calculate overall health risk (weighted average)
        df_health['Overall_Health_Risk'] = (
            df_health['Respiratory_Risk_Score'] * 0.6 + 
            df_health['Cardiovascular_Risk_Score'] * 0.4
        )
        
        # Calculate vulnerable population risk (children, elderly, pregnant women)
        # Higher sensitivity to pollution
        df_health['Vulnerable_Population_Risk'] = df_health['Overall_Health_Risk'] * 1.5
        
        # Categorize risk levels
        df_health['Health_Risk_Category'] = pd.cut(
            df_health['Overall_Health_Risk'],
            bins=[0, 5, 10, 20, 40, float('inf')],
            labels=['Low', 'Moderate', 'High', 'Very High', 'Extreme'],
            include_lowest=True
        )
        
        return df_health
    
    def calculate_who_guideline_compliance(self, df):
        """
        Calculate compliance with WHO guidelines
        
        Args:
            df (pd.DataFrame): Air quality dataframe
            
        Returns:
            dict: Compliance statistics
        """
        compliance = {}
        
        for pollutant, guidelines in self.who_guidelines.items():
            if pollutant in df.columns:
                pollutant_data = df[pollutant].dropna()
                
                if 'daily_mean' in guidelines:
                    threshold = guidelines['daily_mean']
                    exceeding_days = (pollutant_data > threshold).sum()
                    total_days = len(pollutant_data)
                    compliance_rate = ((total_days - exceeding_days) / total_days) * 100
                    
                    compliance[pollutant] = {
                        'threshold': threshold,
                        'exceeding_days': exceeding_days,
                        'total_days': total_days,
                        'compliance_rate': compliance_rate,
                        'mean_concentration': pollutant_data.mean(),
                        'max_concentration': pollutant_data.max()
                    }
        
        return compliance
    
    def calculate_health_benefits(self, df, reduction_percentage=20):
        """
        Calculate potential health benefits from pollution reduction
        
        Args:
            df (pd.DataFrame): Air quality dataframe
            reduction_percentage (float): Percentage reduction in pollution levels
            
        Returns:
            dict: Health benefits analysis
        """
        benefits = {}
        
        # Calculate current health impacts
        current_impacts = self.calculate_health_risk_scores(df)
        
        # Simulate reduced pollution scenario
        df_reduced = df.copy()
        pollutants = ['PM2.5', 'PM10', 'NO2', 'O3', 'SO2']
        
        for pollutant in pollutants:
            if pollutant in df_reduced.columns:
                df_reduced[pollutant] = df_reduced[pollutant] * (1 - reduction_percentage / 100)
        
        # Calculate health impacts with reduced pollution
        reduced_impacts = self.calculate_health_risk_scores(df_reduced)
        
        # Calculate benefits
        respiratory_benefit = (
            current_impacts['Respiratory_Risk_Score'].mean() - 
            reduced_impacts['Respiratory_Risk_Score'].mean()
        )
        
        cardiovascular_benefit = (
            current_impacts['Cardiovascular_Risk_Score'].mean() - 
            reduced_impacts['Cardiovascular_Risk_Score'].mean()
        )
        
        overall_benefit = (
            current_impacts['Overall_Health_Risk'].mean() - 
            reduced_impacts['Overall_Health_Risk'].mean()
        )
        
        benefits = {
            'reduction_percentage': reduction_percentage,
            'respiratory_benefit': respiratory_benefit,
            'cardiovascular_benefit': cardiovascular_benefit,
            'overall_benefit': overall_benefit,
            'estimated_prevented_cases': {
                'respiratory_diseases': respiratory_benefit * 0.1,  # Estimated conversion factor
                'cardiovascular_diseases': cardiovascular_benefit * 0.08,
                'premature_deaths': overall_benefit * 0.02
            }
        }
        
        return benefits
    
    def create_health_impact_visualizations(self, df):
        """
        Create visualizations for health impact analysis
        
        Args:
            df (pd.DataFrame): Air quality dataframe with health scores
            
        Returns:
            dict: Dictionary containing plotly figures
        """
        charts = {}
        
        # Calculate health risk scores
        df_health = self.calculate_health_risk_scores(df)
        
        # 1. Health Risk Distribution
        risk_dist = df_health['Health_Risk_Category'].value_counts()
        
        colors = {
            'Low': '#00e400',
            'Moderate': '#ffff00',
            'High': '#ff7e00',
            'Very High': '#ff0000',
            'Extreme': '#8f3f97'
        }
        
        fig_risk_dist = px.pie(
            values=risk_dist.values,
            names=risk_dist.index,
            title='Health Risk Category Distribution',
            color=risk_dist.index,
            color_discrete_map=colors
        )
        fig_risk_dist.update_layout(height=400, template='plotly_white')
        charts['health_risk_distribution'] = fig_risk_dist
        
        # 2. Health Risk Trends Over Time
        if 'Date' in df_health.columns:
            monthly_health = df_health.groupby(df_health['Date'].dt.to_period('M')).agg({
                'Respiratory_Risk_Score': 'mean',
                'Cardiovascular_Risk_Score': 'mean',
                'Overall_Health_Risk': 'mean'
            }).reset_index()
            
            monthly_health['Date'] = monthly_health['Date'].astype(str)
            
            fig_health_trends = go.Figure()
            
            fig_health_trends.add_trace(go.Scatter(
                x=monthly_health['Date'],
                y=monthly_health['Respiratory_Risk_Score'],
                mode='lines+markers',
                name='Respiratory Risk',
                line=dict(color='#ff6b6b')
            ))
            
            fig_health_trends.add_trace(go.Scatter(
                x=monthly_health['Date'],
                y=monthly_health['Cardiovascular_Risk_Score'],
                mode='lines+markers',
                name='Cardiovascular Risk',
                line=dict(color='#4ecdc4')
            ))
            
            fig_health_trends.add_trace(go.Scatter(
                x=monthly_health['Date'],
                y=monthly_health['Overall_Health_Risk'],
                mode='lines+markers',
                name='Overall Health Risk',
                line=dict(color='#45b7d1')
            ))
            
            fig_health_trends.update_layout(
                title='Health Risk Trends Over Time',
                xaxis_title='Month',
                yaxis_title='Risk Score',
                template='plotly_white',
                height=500
            )
            
            charts['health_trends'] = fig_health_trends
        
        # 3. City-wise Health Risk Comparison
        city_health = df_health.groupby('City').agg({
            'Overall_Health_Risk': 'mean',
            'Respiratory_Risk_Score': 'mean',
            'Cardiovascular_Risk_Score': 'mean',
            'Vulnerable_Population_Risk': 'mean'
        }).round(2).reset_index()
        
        # Top 10 cities with highest health risk
        city_health_top = city_health.nlargest(10, 'Overall_Health_Risk')
        
        fig_city_health = px.bar(
            city_health_top,
            x='City',
            y='Overall_Health_Risk',
            title='Top 10 Cities by Health Risk Score',
            color='Overall_Health_Risk',
            color_continuous_scale='Reds'
        )
        
        fig_city_health.update_layout(
            template='plotly_white',
            height=400,
            xaxis={'tickangle': 45}
        )
        
        charts['city_health_risk'] = fig_city_health
        
        # 4. WHO Guideline Compliance
        compliance = self.calculate_who_guideline_compliance(df)
        
        if compliance:
            compliance_data = []
            for pollutant, data in compliance.items():
                compliance_data.append({
                    'Pollutant': pollutant,
                    'Compliance_Rate': data['compliance_rate'],
                    'Exceeding_Days': data['exceeding_days'],
                    'Total_Days': data['total_days']
                })
            
            compliance_df = pd.DataFrame(compliance_data)
            
            fig_compliance = px.bar(
                compliance_df,
                x='Pollutant',
                y='Compliance_Rate',
                title='WHO Guideline Compliance Rate by Pollutant',
                color='Compliance_Rate',
                color_continuous_scale='RdYlGn',
                range_color=[0, 100]
            )
            
            fig_compliance.update_layout(
                template='plotly_white',
                height=400,
                yaxis_title='Compliance Rate (%)'
            )
            
            charts['who_compliance'] = fig_compliance
        
        # 5. Health Benefits from Pollution Reduction
        reduction_scenarios = [10, 20, 30, 40, 50]
        benefits_data = []
        
        for reduction in reduction_scenarios:
            benefits = self.calculate_health_benefits(df, reduction)
            benefits_data.append({
                'Reduction_Percentage': reduction,
                'Respiratory_Benefit': benefits['respiratory_benefit'],
                'Cardiovascular_Benefit': benefits['cardiovascular_benefit'],
                'Overall_Benefit': benefits['overall_benefit']
            })
        
        benefits_df = pd.DataFrame(benefits_data)
        
        fig_benefits = go.Figure()
        
        fig_benefits.add_trace(go.Scatter(
            x=benefits_df['Reduction_Percentage'],
            y=benefits_df['Respiratory_Benefit'],
            mode='lines+markers',
            name='Respiratory Benefits',
            line=dict(color='#ff6b6b')
        ))
        
        fig_benefits.add_trace(go.Scatter(
            x=benefits_df['Reduction_Percentage'],
            y=benefits_df['Cardiovascular_Benefit'],
            mode='lines+markers',
            name='Cardiovascular Benefits',
            line=dict(color='#4ecdc4')
        ))
        
        fig_benefits.add_trace(go.Scatter(
            x=benefits_df['Reduction_Percentage'],
            y=benefits_df['Overall_Benefit'],
            mode='lines+markers',
            name='Overall Benefits',
            line=dict(color='#45b7d1')
        ))
        
        fig_benefits.update_layout(
            title='Health Benefits from Pollution Reduction',
            xaxis_title='Pollution Reduction (%)',
            yaxis_title='Health Benefit Score',
            template='plotly_white',
            height=500
        )
        
        charts['health_benefits'] = fig_benefits
        
        return charts
    
    def generate_health_recommendations(self, df):
        """
        Generate health recommendations based on air quality data
        
        Args:
            df (pd.DataFrame): Air quality dataframe
            
        Returns:
            dict: Health recommendations
        """
        df_health = self.calculate_health_risk_scores(df)
        compliance = self.calculate_who_guideline_compliance(df)
        
        recommendations = {
            'general': [],
            'vulnerable_populations': [],
            'policy': [],
            'individual': []
        }
        
        # Analyze current health risk levels
        avg_risk = df_health['Overall_Health_Risk'].mean()
        high_risk_days = (df_health['Health_Risk_Category'].isin(['High', 'Very High', 'Extreme'])).sum()
        total_days = len(df_health)
        
        # General recommendations
        if avg_risk > 20:
            recommendations['general'].append("⚠️ High average health risk detected. Immediate intervention needed.")
        elif avg_risk > 10:
            recommendations['general'].append("⚡ Moderate health risk. Regular monitoring recommended.")
        else:
            recommendations['general'].append("✅ Low health risk. Maintain current air quality levels.")
        
        if high_risk_days / total_days > 0.3:
            recommendations['general'].append(f"🚨 {high_risk_days} high-risk days detected ({high_risk_days/total_days*100:.1f}% of total days).")
        
        # Vulnerable population recommendations
        vulnerable_risk = df_health['Vulnerable_Population_Risk'].mean()
        if vulnerable_risk > 30:
            recommendations['vulnerable_populations'].extend([
                "👶 Children should avoid outdoor activities during high pollution days",
                "👴 Elderly individuals should limit outdoor exercise",
                "🤰 Pregnant women should use air purifiers indoors",
                "🫁 People with respiratory conditions should carry rescue medications"
            ])
        
        # WHO compliance analysis
        for pollutant, data in compliance.items():
            if data['compliance_rate'] < 50:
                recommendations['policy'].append(f"📊 {pollutant} exceeds WHO guidelines {data['exceeding_days']} days per year. Urgent policy intervention needed.")
            elif data['compliance_rate'] < 80:
                recommendations['policy'].append(f"📈 {pollutant} compliance at {data['compliance_rate']:.1f}%. Improvement strategies recommended.")
        
        # Individual protection recommendations
        if avg_risk > 15:
            recommendations['individual'].extend([
                "😷 Wear N95 masks when outdoors during high pollution days",
                "🏠 Use HEPA air purifiers indoors",
                "🚗 Avoid exercising near busy roads",
                "🌿 Increase indoor plants for natural air purification",
                "⏰ Plan outdoor activities during early morning hours"
            ])
        
        return recommendations

def create_health_summary_metrics(df):
    """
    Create summary health metrics for display
    
    Args:
        df (pd.DataFrame): Air quality dataframe
        
    Returns:
        dict: Summary health metrics
    """
    calculator = HealthImpactCalculator()
    df_health = calculator.calculate_health_risk_scores(df)
    compliance = calculator.calculate_who_guideline_compliance(df)
    
    # Calculate key metrics
    avg_health_risk = df_health['Overall_Health_Risk'].mean()
    high_risk_percentage = (df_health['Health_Risk_Category'].isin(['High', 'Very High', 'Extreme'])).mean() * 100
    vulnerable_risk = df_health['Vulnerable_Population_Risk'].mean()
    
    # WHO compliance summary
    avg_compliance = np.mean([data['compliance_rate'] for data in compliance.values()]) if compliance else 0
    
    # Most at-risk cities
    city_risk = df_health.groupby('City')['Overall_Health_Risk'].mean().sort_values(ascending=False)
    most_at_risk_city = city_risk.index[0] if not city_risk.empty else "N/A"
    
    return {
        'average_health_risk': avg_health_risk,
        'high_risk_percentage': high_risk_percentage,
        'vulnerable_population_risk': vulnerable_risk,
        'who_compliance_rate': avg_compliance,
        'most_at_risk_city': most_at_risk_city,
        'total_records_analyzed': len(df_health)
    }
